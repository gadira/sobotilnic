package com.example.sobotilnic_online.ui.search_olimps;


import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.sobotilnic_online.Login_or_sign_in;
import com.example.sobotilnic_online.MyOpenHelper;
import com.example.sobotilnic_online.R;
import com.example.sobotilnic_online.ui.my_olimps.Class_for_list;


import java.util.ArrayList;
import java.util.Arrays;
import java.util.stream.Collectors;

public class adapter_for_search_olimps extends RecyclerView.Adapter<adapter_for_search_olimps.MyAdapter> {

    public class MyAdapter extends RecyclerView.ViewHolder {

        TextView textView_name_of_olimps;
        Button buttonAdd_to_my_olimp;


        public MyAdapter(@NonNull View itemView) {
            super(itemView);
            textView_name_of_olimps = itemView.findViewById(R.id.textView_name_of_olimps);
            buttonAdd_to_my_olimp = itemView.findViewById(R.id.buttonAdd_to_my_olimps);

        }
    }

    ArrayList<Class_for_list> searching_results;


    public adapter_for_search_olimps(ArrayList<Class_for_list> searching_results) {
        this.searching_results = searching_results;
    }

    @NonNull
    @Override
    public MyAdapter onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.card_for_olimps, parent, false);
        adapter_for_search_olimps.MyAdapter myAdapter = new MyAdapter(v);
        return myAdapter;
    }

    @Override
    public void onBindViewHolder(@NonNull final MyAdapter holder, int position) {
        holder.textView_name_of_olimps.setText(searching_results.get(position).name_of_olimp);
        holder.textView_name_of_olimps.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                String olimp_name = holder.textView_name_of_olimps.getText().toString();
                //holder.textView_name_of_olimps.setText("intent will be there!!!");
                final AlertDialog.Builder builder = new AlertDialog.Builder(v.getContext());
                builder.setTitle("Добавить в раздел\n *Мои олимпиады*?");
                MyOpenHelper dbHelper = new MyOpenHelper(v.getContext(), "testDB", null, 1);
                SQLiteDatabase readdb = dbHelper.getReadableDatabase();
                SQLiteDatabase writedb = dbHelper.getWritableDatabase();


                Cursor cursor = readdb.rawQuery("select id, name, subjects, level, dates, organisator, place, stages, privileges, site from olimps WHERE name=?", new String[]{olimp_name});
                cursor.moveToFirst();
                cursor.moveToPosition(0);

                String[] a = cursor.getString(3).split("");
                System.out.println(cursor.getString(3));
                String level = "";
                if (a.length == 3) {
                    level = a[1] + ", " + a[2];
                } else if (a.length == 4) {
                    level = a[1] + ", " + a[2] + ", " + a[3];
                } else {
                    level = a[1];
                }

                String dates = cursor.getString(4);
                String organisator = cursor.getString(5);
                String place = cursor.getString(6);
                String stages = cursor.getString(7);
                String privileges = cursor.getString(8);
                String site = cursor.getString(9);


                String[] sub = cursor.getString(2).split(" ");
                String subs = "";
                for (int i = 0; i < sub.length; i++) {
                    cursor = readdb.rawQuery("select id, subject from Subjects WHERE id=?", new String[]{sub[i]});

                    cursor.moveToPosition(0);
                    if (!cursor.getString(1).equals("")) {
                        subs += "; ";
                        subs += cursor.getString(1);
                    }
                }


                builder.setCancelable(true);
                builder.setPositiveButton(android.R.string.ok, new DialogInterface.OnClickListener() { // Кнопка ОК
                    public void onClick(DialogInterface dialog, int which) {

                        Class_for_list example = new Class_for_list(1, "");
                        example.update(holder.textView_name_of_olimps.getText().toString());
                        dialog.dismiss(); // Отпускает диалоговое окно

                    }
                });
                builder.setMessage("Название: " + holder.textView_name_of_olimps.getText().toString() + "\nПредметы: " + subs + "\nУровни: " + level + "\nОрганизаторы: " + organisator + "\nМесто проведения: " + place + "\nПривилегии: " + privileges + "\nЭтапы: " + stages + "\nДаты: " + dates + "\nСайт: " + site);
                builder.show();
                //Dialog dialog_olimp = new Dialog(v.getContext());
                //dialogIfForget.setTitle("Заголовок диалога");
                //dialog_olimp.setContentView(R.layout.dialog_olimp);
                //TextView text = (TextView) dialog_olimp.findViewById(R.id.text_about_olimp);
                //text.setText("dddd");
                //dialog_olimp.
                //dialog_olimp.show();
            }

        });
    }

    @Override
    public int getItemCount() {
        return searching_results.size();
    }

}
