package com.example.sobotilnic_online.ui.my_olimps;

import java.util.ArrayList;
import java.util.Arrays;

public class Class_for_list {

    public int id;
    public String name_of_olimp;
    static ArrayList<String> My_olimps = new ArrayList<>();

    public Class_for_list(int id, String name_of_olimp) {
        this.id = id;
        this.name_of_olimp = name_of_olimp;
    }

    public void update(String a) {
        if (!My_olimps.contains(a)) {
            My_olimps.add(a);
        }
    }

    public void clear() {
        My_olimps.clear();
    }

    public String get() {
        String a = My_olimps.get(My_olimps.size() - 1);
        My_olimps.remove(My_olimps.size() - 1);
        return a;
    }

    public String superget() {
        return My_olimps.get(My_olimps.size() - 1);
    }
}

