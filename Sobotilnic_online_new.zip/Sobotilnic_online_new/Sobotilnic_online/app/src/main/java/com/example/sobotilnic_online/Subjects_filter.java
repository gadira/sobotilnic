package com.example.sobotilnic_online;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.example.sobotilnic_online.ui.my_olimps.Class_for_list;
import com.example.sobotilnic_online.ui.search_olimps.Search_olimpsFragment;

import java.util.ArrayList;

import static com.example.sobotilnic_online.adapter_for_bot_subjects.choice_sub;
import static com.example.sobotilnic_online.ui.profile.ProfileFragment.My_bot_subjects;


public class Subjects_filter extends AppCompatActivity {
    static MyOpenHelper dbHelper;
    SQLiteDatabase readdb;
    SQLiteDatabase writedb;
    Button save_sub;
    public static boolean flag = false;

    //public ArrayList<String> checked = new ArrayList<>();


    TextView text_for_search_olimps_dialog;
    RecyclerView subjects_list;

    ArrayList<Class_for_list> sub_list = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_subjects_filter);


        dbHelper = new MyOpenHelper(this, "testDB", null, 1);
        readdb = dbHelper.getReadableDatabase();
        writedb = dbHelper.getWritableDatabase();

        save_sub = findViewById(R.id.save_sub);
        save_sub.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Subjects_filter.flag = true;
                boolean flag = true;

                //My_bot_subjects = choice_sub;
            }
        });


        subjects_list = findViewById(R.id.subjects_list);
        text_for_search_olimps_dialog = findViewById(R.id.text_for_search_olimps_dialog);


        Cursor cursor = readdb.rawQuery("select id, subject from Subjects", null);
        cursor.moveToFirst();
        int n = cursor.getCount();
        for (int i = 0; i < n; i++) {
            cursor.moveToPosition(i);
            sub_list.add(new Class_for_list(cursor.getInt(0), cursor.getString(1)));
        }

        adapter_for_bot_subjects adapter = new adapter_for_bot_subjects(sub_list);

        LinearLayoutManager layoutManager = new LinearLayoutManager(this);
        subjects_list.setLayoutManager(layoutManager);
        subjects_list.setAdapter(adapter);
    }
}
