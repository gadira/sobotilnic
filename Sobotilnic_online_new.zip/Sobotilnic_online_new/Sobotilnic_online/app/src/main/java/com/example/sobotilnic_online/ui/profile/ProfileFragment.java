package com.example.sobotilnic_online.ui.profile;

import android.app.Dialog;
import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.sobotilnic_online.Login_or_sign_in;
import com.example.sobotilnic_online.R;
import com.example.sobotilnic_online.Subjects_filter;
import com.example.sobotilnic_online.User;
import com.example.sobotilnic_online.adapter_for_bot_subjects;
import com.example.sobotilnic_online.for_user_data;
import com.example.sobotilnic_online.ui.my_olimps.Class_for_list;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

//import com.example.sobotilnic_online.Login_or_sign_in.users_for_check;
public class ProfileFragment extends Fragment {
    public static ArrayList<String> My_bot_subjects = new ArrayList<>();

    private ProfileViewModel profileViewModel;
    ArrayList<Class_for_list> sub_list = new ArrayList<>();
    Button button_exit, save_changes, button_bot_subject;
    for_user_data example = new for_user_data();
    EditText city;
    Switch status;
    TextView name;
    ImageView imageView2;
    public boolean flag = false;

    public DatabaseReference DataBase;
    public String USER_KEY = "User";

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        profileViewModel =
                ViewModelProviders.of(this).get(ProfileViewModel.class);
        View root = inflater.inflate(R.layout.fragment_profile, container, false);
        final TextView textView = root.findViewById(R.id.text_profile);
        profileViewModel.getText().observe(this, new Observer<String>() {
            @Override
            public void onChanged(@Nullable String s) {
                textView.setText(s);
            }
        });


        init();
        getDataFromDB();

        imageView2 = root.findViewById(R.id.imageView2);
        imageView2.setImageResource(R.drawable.icon);

        button_exit = root.findViewById(R.id.button_exit);
        button_exit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                example.name = "";
                example.password = "";
                example.sec_key = "";
                example.city = "";
                example.status = "";
                Intent i;
                i = new Intent(getActivity().getApplicationContext(), Login_or_sign_in.class);
                startActivity(i);
                getActivity().finish();
            }
        });


        city = root.findViewById(R.id.city);
        status = root.findViewById(R.id.status);
        status.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    example.status = "true";
                } else {
                    example.status = "false";
                }
            }
        });
        name = root.findViewById(R.id.name);
        name.setText(example.name);

        city.setText(example.city);

        save_changes = root.findViewById(R.id.save_changes);
        save_changes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String a = city.getText().toString();
                example.city = a;
                flag = true;

                DataBase.child(USER_KEY).setValue(new User("User", example.name, example.password, example.sec_key, example.status, example.city));


                Toast.makeText(getActivity().getApplicationContext(), "Изменения сохранены", Toast.LENGTH_LONG).show();
            }
        });


        button_bot_subject = root.findViewById(R.id.button_bot_subject);
        button_bot_subject.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(v.getContext(), Subjects_filter.class);
                v.getContext().startActivity(i);
            }
        });


        return root;
    }

    private void init() {
        DataBase = FirebaseDatabase.getInstance().getReference(USER_KEY);

    }

    private void onClickSave(String name, String password, String sec_key) {
        String id = DataBase.getKey();
        System.out.println(id + " " + name + " " + password + " " + sec_key);
        User user = new User(id, name, password, sec_key);
        System.out.println(user.id + user.name + user.password + user.sec_key);
        DataBase.push().setValue(user);
    }


    private void getDataFromDB() {
        System.out.println("fffffffff");
        ValueEventListener vListener = new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                int o = 0;


                if (flag == true) {
                    //if(listTemp.size() > 0)listTemp.clear();
                    for (DataSnapshot ds : dataSnapshot.getChildren()) {
                        User user = ds.getValue(User.class);
                        System.out.println("jjj" + user.name + user.password + user.sec_key + user.city + user.status);
                        System.out.println("kkk" + example.name + example.password + example.sec_key + example.city + example.status);
                        if (user.name.equals(example.name) && !(user.name.equals(example.name) && user.sec_key.equals(example.sec_key) && user.password.equals(example.password) && user.city.equals(example.city) && user.status.equals(example.status))) {
                            assert user != null;
                            ds.getRef().removeValue();
                        }
                        //listData.add(user.name);
                        //users_for_check.add(user);
                    }
                    flag = false;
                }
                //adapter.notifyDataSetChanged();

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        };
        DataBase.addValueEventListener(vListener);
    }
}