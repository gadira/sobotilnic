package com.example.sobotilnic_online;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.widget.TextView;

import com.example.sobotilnic_online.ui.my_olimps.Class_for_list;

import java.util.ArrayList;

public class For_materials extends AppCompatActivity {

    static MyOpenHelper dbHelper;
    SQLiteDatabase readdb;
    SQLiteDatabase writedb;
    TextView textView_sub_name;
    RecyclerView sites_list;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_for_materials);


        ArrayList<Class_for_list> materials = new ArrayList<>();

        textView_sub_name = findViewById(R.id.textView_sub_name);
        sites_list = findViewById(R.id.sites_list);




        dbHelper = new MyOpenHelper(this, "DB", null, 1);
        readdb = dbHelper.getReadableDatabase();
        writedb = dbHelper.getWritableDatabase();
        String str = getIntent().getStringExtra("sub");

        Cursor cursorr = readdb.rawQuery("select id from Subjects WHERE subject=?", new String[]{str});
        cursorr.moveToFirst();
        cursorr.moveToPosition(0);
        int index = cursorr.getInt(0);



        Cursor cursor = readdb.rawQuery("select id, description, subject, site from Material WHERE subject=?", new String[]{String.valueOf(index)});
        cursor.moveToFirst();
        int n = cursor.getCount();
        for (int i = 0; i < n; i++) {
            cursor.moveToPosition(i);
            materials.add(new Class_for_list(i, cursor.getString(3) + " (" + cursor.getString(1) + ")"));

        }

        if (materials.size() == 0){
            materials.add(new Class_for_list(1, "На данный момент материалы по предмету не подготовлены;\n" +
                    "вы можете найти полезные ресурсы только по тем предметам, по которым проводится ВсОШ (английский язык, астрономия," +
                    " биология, география, информатика, искусство, испанский язык, история, итальянский язык, китайский язык, литература, математика, немецкий язык, ОБЖ, обществознание, право, технология," +
                    " физика, физическая культура, французский язык, химия, экология, экономика)"));
        }

        adapter_for_sites adapter_for_materials = new adapter_for_sites(materials);

        LinearLayoutManager layoutManager = new LinearLayoutManager(this);
        sites_list.setLayoutManager(layoutManager);
        sites_list.setAdapter(adapter_for_materials);
        textView_sub_name.setText(str);




    }
}
