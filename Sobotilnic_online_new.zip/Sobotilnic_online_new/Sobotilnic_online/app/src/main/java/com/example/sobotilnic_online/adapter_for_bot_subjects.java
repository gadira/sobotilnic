package com.example.sobotilnic_online;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.RadioGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.sobotilnic_online.ui.my_olimps.Class_for_list;

import java.util.ArrayList;

public class adapter_for_bot_subjects extends RecyclerView.Adapter<adapter_for_bot_subjects.MyAdapter> {
    public static  ArrayList<String> choice_sub  = new ArrayList<>();

    public class MyAdapter extends RecyclerView.ViewHolder {



        CheckBox checkBox_subject;


        public MyAdapter(@NonNull View itemView) {
            super(itemView);
            checkBox_subject = itemView.findViewById(R.id.checkBox_subject);

        }
    }
    //public ArrayList<String> choice_sub = new ArrayList<>();

    ArrayList<Class_for_list> subjects_for_filter_and_profile;

    public adapter_for_bot_subjects(ArrayList<Class_for_list> arr) {
        this.subjects_for_filter_and_profile = arr;
    }


    @NonNull
    @Override
    public MyAdapter onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.card_for_subjects, parent, false);
        adapter_for_bot_subjects.MyAdapter myAdapter = new MyAdapter(v);
        return myAdapter;
    }

    @Override
    public void onBindViewHolder(@NonNull final MyAdapter holder, final int position) {
        holder.checkBox_subject.setText(subjects_for_filter_and_profile.get(position).name_of_olimp);
        holder.checkBox_subject.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked){
                    choice_sub.add(holder.checkBox_subject.getText().toString());
                    System.out.println("yyy" + holder.checkBox_subject.getText().toString());}
                else {
                    choice_sub.remove(holder.checkBox_subject.getText().toString());
                }
            }
        });

    }

    @Override
    public int getItemCount() {
        return subjects_for_filter_and_profile.size();
    }


}
