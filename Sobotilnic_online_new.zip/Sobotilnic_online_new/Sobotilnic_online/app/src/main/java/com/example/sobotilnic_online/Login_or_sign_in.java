package com.example.sobotilnic_online;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.Dialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class Login_or_sign_in extends AppCompatActivity {
    public String name, sity, pasword, sec_key, status;
    Button buttonRegistration, buttonSignIn, buttonPressIfForget;
    TextView textHello;
    EditText editLogin, editPassword, editSecretKey;
    Dialog dialogIfForget;
    public DatabaseReference DataBase;
    public String USER_KEY = "User";
    public ArrayList<User> users_for_check = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login_or_sign_in);
        init();
        getDataFromDB();
        buttonPressIfForget = findViewById(R.id.buttonPressIfForget);
        buttonRegistration = findViewById(R.id.buttonRegistration);
        buttonSignIn = findViewById(R.id.buttonSignIn);
        textHello = findViewById(R.id.textHello);
        editLogin = findViewById(R.id.editLogin);
        editPassword = findViewById(R.id.editPassword);
        editSecretKey = findViewById(R.id.editSecretKey);
        for_user_data example = new for_user_data();




        dialogIfForget = new Dialog(Login_or_sign_in.this);
        //dialogIfForget.setTitle("Заголовок диалога");
        dialogIfForget.setContentView(R.layout.dialog_view);
        TextView text = (TextView) dialogIfForget.findViewById(R.id.textForDialog);
        text.setText("Для восстановления пароля напишите на почту dina_gdr@mail.ru, указав в письме тему *Пароль* и направив мне ваш логин и секретное слово. В течение дня придет ответ!");


        buttonSignIn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               // users_for_check.clear();
                if (!editLogin.getText().toString().equals("") && !editPassword.getText().toString().equals("")) {
                    boolean flag = true;
                   // checkUser();
                    System.out.println("sign" + users_for_check.size());
                    for (User user : users_for_check) {
                        if (user.name.equals(editLogin.getText().toString())) {
                            flag = false;
                            if (user.password.equals(editPassword.getText().toString())) {
                                example.name = user.name;
                                example.password = editPassword.getText().toString();
                                example.sec_key = user.sec_key;


                                Intent i;
                                i = new Intent(Login_or_sign_in.this, MainActivity.class);
                                startActivity(i);
                            } else {
                                Toast.makeText(getApplicationContext(), "Похоже, пароль или ваше уникальное имя написаны с ошибкой", Toast.LENGTH_LONG).show();
                            }
                        }
                    }
                    if (flag == true){
                        Toast.makeText(getApplicationContext(), "Пользователь с подобным именем не зарегистрирован", Toast.LENGTH_LONG).show();

                    }
                } else {
                    Toast.makeText(getApplicationContext(), "Что-то не так - вы не ввели логин или пароль", Toast.LENGTH_LONG).show();
                }
            }
        });


        buttonRegistration.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //System.out.println("PPPPPPPP");
               // users_for_check.clear();
                if (!editLogin.getText().toString().equals("") && !editPassword.getText().toString().equals("") && !editSecretKey.getText().toString().equals("")) {

                    boolean flag = true;
                    //checkUser();
                    System.out.println(users_for_check.size() + " " + users_for_check.size());
                    for (User user : users_for_check) {
                        System.out.println(user.name + " ");
                        if (user.name.equals(editLogin.getText().toString())) {
                            System.out.println("yyyyyy");
                            System.out.println(user.name + " " + editLogin.getText().toString());
                            Toast.makeText(getApplicationContext(), "Такое имя уже зарегистрировано в системе! Придумайте свое, уникальное!", Toast.LENGTH_SHORT).show();
                            flag = false;
                            break;
                        }

                    }
                    if (flag == true) {
                        onClickSave(editLogin.getText().toString(), editPassword.getText().toString(), editSecretKey.getText().toString());
                        example.name = editLogin.getText().toString();
                        example.password = editPassword.getText().toString();
                        example.sec_key = editSecretKey.getText().toString();
                        Intent i;
                        i = new Intent(Login_or_sign_in.this, MainActivity.class);
                        startActivity(i);

                    }


                } else {
                    Toast.makeText(getApplicationContext(), "Что-то не так- вы не ввели логин, секретное слово или пароль", Toast.LENGTH_SHORT).show();
                }


            }
        });


        buttonPressIfForget.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //alert.show();
                dialogIfForget.show();
            }
        });

    }

    private void init() {
        DataBase = FirebaseDatabase.getInstance().getReference(USER_KEY);

    }

    private void onClickSave(String name, String password, String sec_key) {
        String id = DataBase.getKey();
        System.out.println(id + " " + name + " " + password + " " + sec_key);
        User user = new User(id, name, password, sec_key);
        System.out.println(user.id + user.name + user.password + user.sec_key);
        DataBase.push().setValue(user);
    }



    private void getDataFromDB()
    {
        ValueEventListener vListener = new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot)
            {
                if(users_for_check.size() > 0)users_for_check.clear();
                //if(listTemp.size() > 0)listTemp.clear();
                for(DataSnapshot ds : dataSnapshot.getChildren())
                {
                    User user = ds.getValue(User.class);
                    assert user != null;
                    //listData.add(user.name);
                    users_for_check.add(user);
                }
                //adapter.notifyDataSetChanged();

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        };
        DataBase.addValueEventListener(vListener);
    }

}