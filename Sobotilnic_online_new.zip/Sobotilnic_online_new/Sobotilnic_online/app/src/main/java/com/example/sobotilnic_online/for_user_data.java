package com.example.sobotilnic_online;

import java.util.ArrayList;

public class for_user_data {
    public static String name, password, sec_key, city="", status="";
    ArrayList<String> subjects = new ArrayList<>();
    ArrayList<String> olimps = new ArrayList<>();
}
