package com.example.sobotilnic_online;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

import java.util.ArrayList;

public class MyOpenHelper extends SQLiteOpenHelper {
    SQLiteDatabase db;

    public MyOpenHelper(@Nullable Context context, @Nullable String name, @Nullable SQLiteDatabase.CursorFactory factory, int version) {
        super(context, name, factory, version);
    }


    @Override
    public void onCreate(SQLiteDatabase db) {
        this.db = db;
        String query = "CREATE TABLE Material\n" +
                "    (id INTEGER PRIMARY KEY AUTOINCREMENT,\n" +
                "    subject  INTEGER,\n" +
                " description STRING, site STRING)";
        String query2 = "CREATE TABLE Subjects\n" +
                "    (id INTEGER PRIMARY KEY AUTOINCREMENT,\n" +
                "    subject  STRING)";

        String query3 = "CREATE TABLE olimps (id INTEGER PRIMARY KEY " +
                "AUTOINCREMENT NOT NULL UNIQUE, name STRING UNIQUE NOT NULL, " +
                "subjects STRING NOT NULL, level STRING NOT NULL, dates S" +
                "TRING NOT NULL, organisator STRING NOT NULL, plac" +
                "e STRING NOT NULL, stages STRING NOT NULL, privileges" +
                " STRING NOT NULL, site STRING NOT NULL)";
        db.execSQL(query);
        db.execSQL(query2);
        db.execSQL(query3);
        String q = "INSERT INTO material (id, subject, description, site) VALUES (1, 59, 'Много задач, собранных по темам', 'https://mathus.ru/math/');\n" +
                "INSERT INTO material (id, subject, description, site) VALUES (2, 59, 'Агаханов Н. Х., Богданов И. И., Кожевников П. А., Подлипский О. К., Терешин Д. А. Всероссийская олимпиада школьников по математике 1993-2009', 'https://ugrafmsh.ru/wp-content/uploads/2015/09/Vserossiyskie-olipiadyi-shkolnikov-po-matematike-1993-2006_Agahanov-i-dr_2007.pdf');\n" +
                "INSERT INTO material (id, subject, description, site) VALUES (3, 59, 'Кохась К. П., Берлов С. Л., Власова Н.Ю., Петров Ф. В., Солынин А. А., Храбров А. И. Задачи Санкт-Петербургской олимпиады школьников 2019 год', 'https://ru.ru1lib.org/book/13157428/65c1b2');\n" +
                "INSERT INTO material (id, subject, description, site) VALUES (4, 59, 'Кохась К. П., Берлов С. Л., Власова Н.Ю., Петров Ф. В., Солынин А. А., Храбров А. И. Задачи Санкт-Петербургской олимпиады школьников 2017 год', 'https://ru.ru1lib.org/book/11633605/26a25f');\n" +
                "INSERT INTO material (id, subject, description, site) VALUES (5, 59, 'Кохась К. П., Берлов С. Л., Власова Н.Ю., Петров Ф. В., Солынин А. А., Храбров А. И. Задачи Санкт-Петербургской олимпиады школьников 2015 год', 'https://ru.ru1lib.org/book/2914995/101d03');\n" +
                "INSERT INTO material (id, subject, description, site) VALUES (6, 59, 'Кохась К. П., Берлов С. Л., Власова Н.Ю., Петров Ф. В., Солынин А. А., Храбров А. И. Задачи Санкт-Петербургской олимпиады школьников 2019 год', 'https://ru.ru1lib.org/book/2435421/8c9ed8');\n" +
                "INSERT INTO material (id, subject, description, site) VALUES (7, 59, 'Акопян А. В. Геометрия в картинках', 'https://www.mccme.ru/free-books/akopyan/Akopyan.pdf');\n" +
                "INSERT INTO material (id, subject, description, site) VALUES (8, 59, 'Прасолов В. В. Задачи по планиметрии', 'https://ru.ru1lib.org/book/447198/410635');\n" +
                "INSERT INTO material (id, subject, description, site) VALUES (9, 59, 'Задачи по математике со всего мира', 'https://artofproblemsolving.com/');\n" +
                "INSERT INTO material (id, subject, description, site) VALUES (10, 59, 'Много задач по математике, собранных по темам', 'http://problems.ru/');\n" +
                "INSERT INTO material (id, subject, description, site) VALUES (11, 59, 'Боревич З. И. Определители и матрицы (начало линейной алгебры)', 'https://ru.ru1lib.org/book/1314625/9bf944');\n" +
                "INSERT INTO material (id, subject, description, site) VALUES (12, 59, 'Мельников О. И. Теория графов в занимательных задачах (для комбинаторики)', 'https://ru.ru1lib.org/book/2833610/57f586');\n" +
                "INSERT INTO material (id, subject, description, site) VALUES (13, 59, 'Муштари Д. Х. Подготовка к математическим олимпиадам', 'https://ru.ru1lib.org/book/3560240/fee74c');\n" +
                "INSERT INTO material (id, subject, description, site) VALUES (14, 59, 'Математика. Районные олимпиады. 6—11 классы / Агаханов Н.X., Подлипский О.К.', 'https://yadi.sk/d/6NmJ9TZOu9ZEd');\n" +
                "INSERT INTO material (id, subject, description, site) VALUES (15, 59, 'Математика. Областные олимпиады. 8—11 классы / Н. X. Агаханов, И. И. Богданов, П. А. Кожевников', 'https://yadi.sk/d/YrI_ZFs6u9ZJ6');\n" +
                "INSERT INTO material (id, subject, description, site) VALUES (16, 59, 'Математика. Всероссийские олимпиады. Вып. 1 / Н. X. Агаханов, И. И. Богданов, П. А. Кожевников', 'https://yadi.sk/d/urqWMq7Nu9ZLF');\n" +
                "INSERT INTO material (id, subject, description, site) VALUES (17, 59, 'Математика. Всероссийские олимпиады. Вып. 2 / Н. X. Агаханов, О. К. Подлипский', 'https://yadi.sk/i/DGbc1QmFu9ZMf');\n" +
                "INSERT INTO material (id, subject, description, site) VALUES (18, 59, 'Математика. Международные олимпиады / Н. X. Агаханов, П. А. Кожевников, Д. А. Терешин', 'https://yadi.sk/d/qJS0l1HLu9ZNT');\n" +
                "INSERT INTO material (id, subject, description, site) VALUES (19, 92, 'Ландау Л. Д., Ахиезер А. И., Лифшиц Е. М. Механика и молекулярная физика в курсе общей физики', 'https://ru.ru1lib.org/book/2461865/36b1a7');\n" +
                "INSERT INTO material (id, subject, description, site) VALUES (20, 92, 'Зильберман Г. Е. Электричество и магнетизм', 'https://ru.ru1lib.org/book/450985/7aea8d');\n" +
                "INSERT INTO material (id, subject, description, site) VALUES (21, 92, 'Воробьев И. И., Зубков П. И., Кутузова Г. А. Под редакцией Савченко О. Я. 3-е издание. Задачи по физике', 'https://ru.ru1lib.org/book/1150220/534701');\n" +
                "INSERT INTO material (id, subject, description, site) VALUES (22, 92, 'Здесь есть важная информация по олимпиадной физике, программа, которую надо знать к каждому этапу Всероссийской олимпиады школьников по физике, и хороший список литературы', 'http://4ipho.ru/');\n" +
                "INSERT INTO material (id, subject, description, site) VALUES (23, 92, 'Вишнякова Е.А. Физика. Углубленный курс с решениями и указаниями.pdf', 'https://vk.com/doc603004997_566780664?hash=49b60c4c002be7af02&dl=1b059ddd2537082849');\n" +
                "INSERT INTO material (id, subject, description, site) VALUES (24, 92, 'Вишнякова Е.А. Физика. Сборник Задач.pdf', 'https://vk.com/doc603004997_566779911?hash=971efd2d79f1446d2e&dl=8b702dcd902d2de2cb');\n" +
                "INSERT INTO material (id, subject, description, site) VALUES (25, 92, 'Козел С. М., Рашба Э. И., Славатинский С. А. Сборник задач по физике. Задачи МФТИ', 'https://vk.com/doc191450968_561605908?hash=8cd8b02b0d437055ee&dl=db775d523a1abf85b8');\n" +
                "INSERT INTO material (id, subject, description, site) VALUES (26, 92, 'Задачи московских городских олимпиад по физике 1986–2007', 'https://vk.com/doc173982279_516799976?hash=80b14f97f5a3c01624&dl=31371c416c0609e335');\n" +
                "INSERT INTO material (id, subject, description, site) VALUES (27, 92, 'Физическая олимпиада: экспериментальный тур', 'https://vk.com/doc-186133701_512986727?hash=06ed1acb626f9fbb05&dl=61e3f5005226eae6c0');\n" +
                "INSERT INTO material (id, subject, description, site) VALUES (28, 92, 'Наряду с традиционным материалом в сборник включены задачи по теории относительности (включая релятивистские столкновения, ускорители, рождение частиц и т. п.), квантовой механике (соотношение неопределенностей, волны де Бройля, потенциальный барьер, вырожденное состояние вещества), статистике, волновой и квантовой оптике, атомной и ядерной физике', 'https://vk.com/doc191450968_493111277?hash=a5a16ffacd32f7f437&dl=055724654a1f43204d');\n" +
                "INSERT INTO material (id, subject, description, site) VALUES (29, 92, 'Манида C.Н. Физика. Решение задач повышенной сложности', 'https://ru.ru1lib.org/book/2987883/94b81f');\n" +
                "INSERT INTO material (id, subject, description, site) VALUES (30, 92, 'Баканина Л.П., Белонучкин В.Е., Козел С.М. Сборник задач по физике для 10-11 классов с углубленным изучением физики', 'https://ru.ru1lib.org/book/2445729/d263e4');\n" +
                "INSERT INTO material (id, subject, description, site) VALUES (31, 92, 'Всероссийские олимпиады по физике 1992-2001: Учеб. пособие для учащихся ст. кл. общеобразоват. учреждений', 'https://ru.ru1lib.org/book/454382/50105a');\n" +
                "INSERT INTO material (id, subject, description, site) VALUES (32, 92, 'Слободецкий И.Ш., Орлов В.А. Всесоюзные Олимпиады по физике: Пособие для учащихся', 'https://ru.ru1lib.org/book/560072/9bc049');\n" +
                "INSERT INTO material (id, subject, description, site) VALUES (33, 92, 'С.Д. Варламов, А.Р. Зильберман, В.И. Зинковский. «Экспериментальные задачи на уроках физики и физических олимпиадах»', 'https://ru.ru1lib.org/book/2914989/53131e');\n" +
                "INSERT INTO material (id, subject, description, site) VALUES (34, 92, 'О.Ф. Кабардин, В.А. Орлов «Международные физические олимпиады»', 'https://ru.ru1lib.org/book/447352/1d7846');\n" +
                "INSERT INTO material (id, subject, description, site) VALUES (35, 92, 'С.Д. Варламов и др. «Задачи Московских городских олимпиад по физике 1986-2005 (2007)', 'https://ru.ru1lib.org/book/720356/f0e785');\n" +
                "INSERT INTO material (id, subject, description, site) VALUES (36, 92, 'Задачники библиотечки «Квант» (А.И. Будзин, А.Р. Зильберман, С.С. Кротов «Раз задача, два задача…», а также И.Ш. Слободецкий, Л.Г. Асламазов «Задачи по физике»)', 'https://ru.ru1lib.org/book/2935100/5c70fb');\n" +
                "INSERT INTO material (id, subject, description, site) VALUES (37, 8, 'Кононович Э. В., Мороз В. И. Общий курс астрономии', 'https://ru.ru1lib.org/book/2702699/1c9f58');\n" +
                "INSERT INTO material (id, subject, description, site) VALUES (38, 8, 'Karttunen, P. Kroger, H. Oja (Eds.) Fundamental Astronomy', 'https://ru.ru1lib.org/book/2837988/2c4017');\n" +
                "INSERT INTO material (id, subject, description, site) VALUES (39, 8, 'Сурдин В. Г. Астрономические задачи с решениями', 'https://ru.ru1lib.org/book/2702446/d34ef6');\n" +
                "INSERT INTO material (id, subject, description, site) VALUES (40, 8, 'Здесь можно найти архив задач Всероссийской олимпиады школьников по астрономии', 'http://www.astroolymp.ru/');\n" +
                "INSERT INTO material (id, subject, description, site) VALUES (41, 8, 'На сайте можно найти новости олимпиад и кружков по астрономии в Санкт-Петербурге, а также полезные ссылки', 'http://school.astro.spbu.ru/');\n" +
                "INSERT INTO material (id, subject, description, site) VALUES (42, 8, 'О. С. Угольников. Всероссийская олимпиада школьников по астрономии: содержание олимпиады и подготовка конкурсантов', 'https://ru.ru1lib.org/book/2996991/fe26ff');\n" +
                "INSERT INTO material (id, subject, description, site) VALUES (43, 8, 'В. В. Иванов, А. В. Кривов, П. А. Денисенков. Парадоксальная Вселенная. 250 задач по астрономии', 'http://www.astro.spbu.ru/staff/viva/Book/Book.html');\n" +
                "INSERT INTO material (id, subject, description, site) VALUES (44, 36, 'Изучение языков программирования и алгоритмы', 'https://informatics.msk.ru/?');\n" +
                "INSERT INTO material (id, subject, description, site) VALUES (45, 36, 'Огромное количество задач по информатике', 'https://codeforces.com/');\n" +
                "INSERT INTO material (id, subject, description, site) VALUES (46, 36, 'Здесь содержится большое количество задач по программированию различного уровня', 'http://informatics.mccme.ru/');\n" +
                "INSERT INTO material (id, subject, description, site) VALUES (47, 36, 'Энциклопедия по дискретной математике и теории алгоритмов, составленная студентами ИТМО. В ней описано большинство алгоритмов, используемых на олимпиадах по программированию', NULL);\n" +
                "INSERT INTO material (id, subject, description, site) VALUES (48, 36, ' Мини-энциклопедия, содержащая наиболее популярные алгоритмы в олимпиадной информатике, к большинству из которых приведены реализации и примеры использования', 'http://e-maxx.ru/algo/');\n" +
                "INSERT INTO material (id, subject, description, site) VALUES (49, 36, 'Томас Х. Кормен, Чарльз И. Лейзерсон, Рональд Л. Ривест, Клиффорд Штайн. Алгоритмы. Построение и анализ', 'https://ru.ru1lib.org/book/2706263/3d7d71');\n" +
                "INSERT INTO material (id, subject, description, site) VALUES (50, 36, 'Робин Уилсон. Введение в теорию графов', 'https://vk.com/doc191450968_576793782?hash=4af9fc96e2b72be9cc&dl=02f12cea2344a0f217');\n" +
                "INSERT INTO material (id, subject, description, site) VALUES (51, 36, 'Меньшиков Ф. В. Олимпиадные задачи по программированию', 'https://ru.ru1lib.org/book/468710/d1beb0');\n" +
                "INSERT INTO material (id, subject, description, site) VALUES (52, 36, 'Бхаргава А. Грокаем алгоритмы. Иллюстрированное пособие для программистов и любопытсвующих', 'https://vk.com/doc191450968_572015802?hash=7af779cd24be04e2fc&dl=3f8b7fac799bf9f4d0');\n" +
                "INSERT INTO material (id, subject, description, site) VALUES (53, 36, 'С.А. Абрамов - Математические построения и программирование', 'https://vk.com/doc191450968_500146558?hash=bf22241e951a2de586&dl=4be0d720725b3a82d1');\n" +
                "INSERT INTO material (id, subject, description, site) VALUES (54, 36, 'Шень А. Программирование: теоремы и задачи', 'https://vk.com/doc191450968_563914823?hash=f24977ca8738beddcc&dl=b0a1b45143e37d4d6e');\n" +
                "INSERT INTO material (id, subject, description, site) VALUES (55, 36, 'Златопольский Д.М. - Сборник задач по программированию', 'https://vk.com/doc191450968_485078656?hash=f747ebd6c4dba81127&dl=7d7c4b9fee18b49d46');\n" +
                "INSERT INTO material (id, subject, description, site) VALUES (56, 36, 'Кирюхин В.М., Окулов С. М. Методика решения задач по информатике. Международные олимпиады', 'https://ru.ru1lib.org/book/1285633/3132a7');\n" +
                "INSERT INTO material (id, subject, description, site) VALUES (57, 36, 'Шень, А.Х. Практикум по методам построения алгоритмов', 'https://ru.ru1lib.org/book/2702507/e2ef0e');\n" +
                "INSERT INTO material (id, subject, description, site) VALUES (58, 98, 'Клайден Дж., Гривз Н., Уоррен С., Уозерс П. Органическая химия', 'https://ru.ru1lib.org/book/3050723/d89a57');\n" +
                "INSERT INTO material (id, subject, description, site) VALUES (59, 98, 'Реутов О. А., Курц А. Л., Бутин К. П. Органическая химия, часть 1', 'https://ru.ru1lib.org/book/2624147/747cb3');\n" +
                "INSERT INTO material (id, subject, description, site) VALUES (60, 98, 'Реутов О. А., Курц А. Л., Бутин К. П. Органическая химия, часть 2', 'https://ru.ru1lib.org/book/2624442/4d6e48');\n" +
                "INSERT INTO material (id, subject, description, site) VALUES (61, 98, 'Реутов О. А., Курц А. Л., Бутин К. П. Органическая химия, часть 3', 'https://ru.ru1lib.org/book/2624443/a049f9');\n" +
                "INSERT INTO material (id, subject, description, site) VALUES (62, 98, 'Реутов О. А., Курц А. Л., Бутин К. П. Органическая химия, часть 4', 'https://ru.ru1lib.org/book/2624148/e15589');\n" +
                "INSERT INTO material (id, subject, description, site) VALUES (63, 98, 'Неорганическая химия, том 1', 'https://drive.google.com/open?id=12AxeNuB6_SiYYSVVEwSyuURoS2fdmm-H');\n" +
                "INSERT INTO material (id, subject, description, site) VALUES (64, 98, 'Неорганическая химия, том 2', 'https://drive.google.com/open?id=1AbxMIqj_2AIeZ3WmL8og0OqsmP4ofjJ5');\n" +
                "INSERT INTO material (id, subject, description, site) VALUES (65, 98, 'Неорганическая химия, том 3, книга 1', 'https://drive.google.com/open?id=1TWQQRUDmwUH-_SADP83ZIF7SIrr1E2hF');\n" +
                "INSERT INTO material (id, subject, description, site) VALUES (66, 98, 'Неорганическая химия, том 3, книга 2', 'https://drive.google.com/open?id=1xDwAsrDPIpzgI_vrRccVHZ9OosC2TwTV');\n" +
                "INSERT INTO material (id, subject, description, site) VALUES (67, 98, 'Гринвуд Н. Н., Эрншо А. Химия элементов', 'https://ru.ru1lib.org/book/541707/507251');\n" +
                "INSERT INTO material (id, subject, description, site) VALUES (68, 98, 'Шрайвер Д., Эткинс П. Неорганическая химия, том 1', 'https://ru.ru1lib.org/book/2290030/83afaf');\n" +
                "INSERT INTO material (id, subject, description, site) VALUES (69, 98, 'Шрайвер Д., Эткинс П. Неорганическая химия, том 2', 'https://ru.ru1lib.org/book/2290861/eda38d');\n" +
                "INSERT INTO material (id, subject, description, site) VALUES (70, 98, 'Еремин В. В. Теоретическая и математическая химия', 'https://ru.ru1lib.org/book/2721558/a5d4a0');\n" +
                "INSERT INTO material (id, subject, description, site) VALUES (71, 98, 'Материалы по всем областям химии', 'https://ocw.mit.edu/index.htm');\n" +
                "INSERT INTO material (id, subject, description, site) VALUES (72, 98, 'Перевод лекций и прочих учебных материалов ведущих вузов планеты', 'https://vk.com/kursomir');\n" +
                "INSERT INTO material (id, subject, description, site) VALUES (73, 98, 'Глинка Н.Л. Общая химия', 'https://ru.ru1lib.org/book/626026/29de97');\n" +
                "INSERT INTO material (id, subject, description, site) VALUES (74, 98, 'Гуревич П.А., Кабешов М.А. Органическая химия', 'https://ru.ru1lib.org/book/2409756/df5bf8');\n" +
                "INSERT INTO material (id, subject, description, site) VALUES (75, 98, 'Курамшин А.И. Задачи районных, городских и республиканских химических олимпиад школьников республики Татарстан', 'https://ru.ru1lib.org/book/3099537/1fbb84');\n" +
                "INSERT INTO material (id, subject, description, site) VALUES (76, 98, 'Травень В.Ф. Органическая химия, том 1', 'https://ru.ru1lib.org/book/2915661/3bdc41');\n" +
                "INSERT INTO material (id, subject, description, site) VALUES (77, 98, 'Травень В.Ф. Органическая химия, том 2', 'https://ru.ru1lib.org/book/2915662/0cc1a2');\n" +
                "INSERT INTO material (id, subject, description, site) VALUES (78, 98, 'Травень В.Ф. Органическая химия, том 3', 'https://ru.ru1lib.org/book/2915663/e4157a');\n" +
                "INSERT INTO material (id, subject, description, site) VALUES (79, 11, 'Гайтон А., Холл Дж., Медицинская физиология', 'https://ru.ru1lib.org/book/4994991/bdce2c');\n" +
                "INSERT INTO material (id, subject, description, site) VALUES (80, 11, 'Рупперт Э. Э. Зоология беспозвоночных, том 1', 'https://ru.ru1lib.org/book/633432/c62208');\n" +
                "INSERT INTO material (id, subject, description, site) VALUES (81, 11, 'Рупперт Э. Э. Зоология беспозвоночных, том 2', 'https://ru.ru1lib.org/book/633433/1a46ec');\n" +
                "INSERT INTO material (id, subject, description, site) VALUES (82, 11, 'Рупперт Э. Э. Зоология беспозвоночных, том 3', 'https://ru.ru1lib.org/book/3060643/fc8351');\n" +
                "INSERT INTO material (id, subject, description, site) VALUES (83, 11, 'Рупперт Э. Э. Зоология беспозвоночных, том 4', 'https://ru.ru1lib.org/book/633437/4a3384');\n" +
                "INSERT INTO material (id, subject, description, site) VALUES (84, 11, 'Ромер А., Парсонс Т. Анатомия позвоночных, том 1', 'https://ru.ru1lib.org/book/3092738/df656e');\n" +
                "INSERT INTO material (id, subject, description, site) VALUES (85, 11, 'Ромер А., Парсонс Т. Анатомия позвоночных, том 2', 'https://ru.ru1lib.org/book/3092743/5552b7');\n" +
                "INSERT INTO material (id, subject, description, site) VALUES (86, 11, 'Зитте П., Вайлер Э. В., Ботаника, том 1', 'https://ru.ru1lib.org/book/3095552/cf251c');\n" +
                "INSERT INTO material (id, subject, description, site) VALUES (87, 11, 'Зитте П., Вайлер Э. В., Ботаника, том 2', 'https://ru.ru1lib.org/book/3095552/cf251c');\n" +
                "INSERT INTO material (id, subject, description, site) VALUES (88, 11, 'Зитте П., Вайлер Э. В., Ботаника, том 3', 'https://ru.ru1lib.org/book/3095755/bfb5bf');\n" +
                "INSERT INTO material (id, subject, description, site) VALUES (89, 11, 'Зитте П., Вайлер Э. В., Ботаника, том 4', 'https://ru.ru1lib.org/book/3095757/549fed');\n" +
                "INSERT INTO material (id, subject, description, site) VALUES (90, 11, 'Льюин Б. Гены, Клетки', 'https://vk.com/doc-44220375_260266125?hash=0844b1ff591cc5bb9b&dl=90e9160f67b3f66331');\n" +
                "INSERT INTO material (id, subject, description, site) VALUES (91, 11, 'Кюнель В. Цветной атлас по цитологии, гистологии и микроскопической анатомии,  Фаллер А., Шюнке М. Анатомия и физиология человека', 'https://ru.ru1lib.org/book/2373606/c2fbd5');\n" +
                "INSERT INTO material (id, subject, description, site) VALUES (92, 11, 'Watson J. D. Molecular biology of the gene', 'https://ru.ru1lib.org/book/2064360/875f4b');\n" +
                "INSERT INTO material (id, subject, description, site) VALUES (93, 11, 'Futuyma D. Evolution', 'https://ru.ru1lib.org/book/2325474/f08119');\n" +
                "INSERT INTO material (id, subject, description, site) VALUES (94, 11, 'Michael T. Madigan Brock Biology of Microorganisms', 'https://ru.ru1lib.org/book/3554713/c473a8');\n" +
                "INSERT INTO material (id, subject, description, site) VALUES (95, 11, 'Peter H. Raven Biology of Plants', 'https://ru.ru1lib.org/book/1012011/23a0bc');\n" +
                "INSERT INTO material (id, subject, description, site) VALUES (96, 11, 'Самый научный среди научно-популярных ресурсов', 'https://biomolecula.ru/');\n" +
                "INSERT INTO material (id, subject, description, site) VALUES (97, 11, 'Здесь публикуются даже не новости, а пересказы новых громких научных работ', 'https://biomolecula.ru/');\n" +
                "INSERT INTO material (id, subject, description, site) VALUES (98, 11, 'Журнал освещает многие необычные и уникальные темы', 'http://batrachospermum.ru/');\n" +
                "INSERT INTO material (id, subject, description, site) VALUES (99, 101, 'Юджин Одум «Экология»', 'https://ru.ru1lib.org/book/528618/07e0fb');\n" +
                "INSERT INTO material (id, subject, description, site) VALUES (100, 101, 'Чернова Н. И., Былова А. Н. «Общая экология»', 'https://ru.ru1lib.org/book/759736/ac1ff9');\n" +
                "INSERT INTO material (id, subject, description, site) VALUES (101, 101, 'На сайте можно найти последние новости природоохранного законодательства', 'https://biomolecula.ru/');\n" +
                "INSERT INTO material (id, subject, description, site) VALUES (102, 101, 'десь можно найти важные сведения, непосредственно касающиеся экологии', 'https://elementy.ru/');\n" +
                "INSERT INTO material (id, subject, description, site) VALUES (103, 101, 'И. А. Шилов. Экология', 'https://ru.ru1lib.org/book/2446390/fdac56');\n" +
                "INSERT INTO material (id, subject, description, site) VALUES (104, 101, 'Наумова. Б. М. Миркин. Основы общей экологии', 'https://ru.ru1lib.org/book/3287358/0d02e8');\n" +
                "INSERT INTO material (id, subject, description, site) VALUES (105, 101, 'Воронов. Основы общей экологии', 'https://ru.ru1lib.org/book/621640/43db39');\n" +
                "INSERT INTO material (id, subject, description, site) VALUES (106, 101, 'Марфенин. Устойчивое развитие человечества', 'http://ecoportus.ru/node/606');\n" +
                "INSERT INTO material (id, subject, description, site) VALUES (107, 101, 'Устойчивое развите. Новые вызовы', 'https://www.hse.ru/data/2016/08/09/1125668218/%D0%A3%D1%81%D1%82%20%D1%80%D0%B0%D0%B7%D0%B2%D0%B8%D1%82%D0%B8%D0%B5%20%D0%9D%D0%BE%D0%B2%D1%8B%D0%B5%20%D0%B2%D1%8B%D0%B7%D0%BE%D0%B2%D1%8B%20full.pdf');\n" +
                "INSERT INTO material (id, subject, description, site) VALUES (108, 101, 'Экология и культура. Человек и природа', 'http://sustainabledevelopment.ru/upload/File/Books%202015/1_6_Cult.pdf');\n" +
                "INSERT INTO material (id, subject, description, site) VALUES (109, 101, 'Захаров. Эколого-биологические основы УР', 'https://docplayer.ru/45732386-Ekologo-biologicheskie-osnovy-ustoychivogo-razvitiya-2014-v-m-zaharov.html');\n" +
                "INSERT INTO material (id, subject, description, site) VALUES (110, 101, 'С. Н. Бобылев. В. М. Захаров. Кризис. Экономика и экология', 'http://sustainabledevelopment.ru/upload/File/Books/Inst_book_5.pdf');\n" +
                "INSERT INTO material (id, subject, description, site) VALUES (111, 101, 'С. Н. Бобылев. Индикаторотры УР', 'http://ecologyandculture.ru/upload/File/Bobylev_1.pdf');\n" +
                "INSERT INTO material (id, subject, description, site) VALUES (112, 101, 'В. М. Захаров. Устойчивое развитие стран СНГ', 'http://sustainabledevelopment.ru/index.php?cnt=344');\n" +
                "INSERT INTO material (id, subject, description, site) VALUES (113, 17, 'Романова Э., Алексеева Н., Аршинова М. Физическая география материков и океанов в 2 томах, Максаковский В. П. География. Экономическая и социальная география мира', 'https://vk.com/doc-89821077_437708393?hash=348c081ba47c2c47a6&dl=7341cc0ace2fc26a2f');\n" +
                "INSERT INTO material (id, subject, description, site) VALUES (114, 17, 'Михайлов В. Н., Добровольский А. Д., Добролюбов С. А. Гидрология', 'https://ru.ru1lib.org/book/2439377/5bb9df');\n" +
                "INSERT INTO material (id, subject, description, site) VALUES (115, 17, 'Хромов С. П., Петросянц М. А. Метеорология и климатология', 'https://ru.ru1lib.org/book/1273360/c85303');\n" +
                "INSERT INTO material (id, subject, description, site) VALUES (116, 17, 'Геннадиев А. Н., Глазовская М. А. География почв с основами почвоведения', 'https://ru.ru1lib.org/book/2834194/dbbfcb');\n" +
                "INSERT INTO material (id, subject, description, site) VALUES (117, 17, 'Рычагов Г. И. Общая геоморфология', 'https://ru.ru1lib.org/book/578446/b8c9c7');\n" +
                "INSERT INTO material (id, subject, description, site) VALUES (118, 17, 'Божок А. П., Харченко А. С. Топография с основами геодезии', 'https://ru.ru1lib.org/book/2992847/fc9685');\n" +
                "INSERT INTO material (id, subject, description, site) VALUES (119, 17, 'Абдурахманов Г. М., Криволуцкий Д. А., Мяло Е. Г., Огуреева Г. Н. Биогеография', 'https://ru.ru1lib.org/book/1019127/288333');\n" +
                "INSERT INTO material (id, subject, description, site) VALUES (120, 17, 'Алексеев А. И., Колосов В. А. Социально-экономическая география России', 'https://ru.ru1lib.org/book/2862322/c9abfd');\n" +
                "INSERT INTO material (id, subject, description, site) VALUES (121, 17, 'Магидович И. П., Магидович В. И. Очерки по истории географических открытий', 'https://ru.ru1lib.org/book/2521954/c59286');\n" +
                "INSERT INTO material (id, subject, description, site) VALUES (122, 17, 'Вся наиболее свежая и актуальная информация по социально-экономическим показателям в России – здесь', 'http://www.gks.ru/');\n" +
                "INSERT INTO material (id, subject, description, site) VALUES (123, 17, 'Здесь – топографические карты на весь мир', 'http://loadmap.net/ru');\n" +
                "INSERT INTO material (id, subject, description, site) VALUES (124, 17, 'Паблик ВКонтакте, содержащий 2000 различных учебников', 'https://vk.com/geolibrary');\n" +
                "INSERT INTO material (id, subject, description, site) VALUES (125, 17, 'Справочник о природе России и мира', 'http://www.ecosystema.ru/');\n" +
                "INSERT INTO material (id, subject, description, site) VALUES (126, 17, 'Физико-географический атлас мира', 'http://geochemland.ru/uchebnye-materialy/fgam');\n" +
                "INSERT INTO material (id, subject, description, site) VALUES (127, 102, 'Матвеева Т. Ю., Никулина И. Н. Основы экономической теории', 'https://ru.ru1lib.org/book/3089436/d5e615');\n" +
                "INSERT INTO material (id, subject, description, site) VALUES (128, 102, 'Акимов Д. В., Дичева О. В., Щукина Л. Б. Задания по экономике: От простых до олимпиадных', 'https://ru.ru1lib.org/book/3224635/6e3269');\n" +
                "INSERT INTO material (id, subject, description, site) VALUES (129, 102, 'Бойко, М. Азы экономики', 'https://ru.ru1lib.org/book/2828767/254774');\n" +
                "INSERT INTO material (id, subject, description, site) VALUES (130, 102, 'Мэнкью Н. Г. Принципы экономикс', 'https://ru.ru1lib.org/book/468820/0f6bac');\n" +
                "INSERT INTO material (id, subject, description, site) VALUES (131, 102, 'Вэриан, Х. Р. Микроэкономика: Промежуточный уровень', 'https://ru.ru1lib.org/book/571677/561c47');\n" +
                "INSERT INTO material (id, subject, description, site) VALUES (132, 102, 'Пратусевич М. Я., Столбов К. М., Головин А. Н. Алгебра и начала математического анализа. 10 класс', 'https://ru.ru1lib.org/book/1276217/3525a6');\n" +
                "INSERT INTO material (id, subject, description, site) VALUES (133, 102, 'Пратусевич М. Я., Столбов К. М., Головин А. Н. Алгебра и начала математического анализа. 11 класс', 'https://ru.ru1lib.org/book/1276218/4477af');\n" +
                "INSERT INTO material (id, subject, description, site) VALUES (134, 102, 'Ландсбург С. Экономист на диване', 'https://ru.ru1lib.org/book/3049530/f9e4f2');\n" +
                "INSERT INTO material (id, subject, description, site) VALUES (135, 102, 'Дабнер С. Д., Левитт С. Д. Фрикономика', 'https://ru.ru1lib.org/book/2916442/eaacf7');\n" +
                "INSERT INTO material (id, subject, description, site) VALUES (136, 102, 'Сонин, К. И. Sonin.ru: Уроки экономики', 'https://ru.ru1lib.org/book/1019566/35ee30');\n" +
                "INSERT INTO material (id, subject, description, site) VALUES (137, 102, 'Тут собраны условия и решения олимпиад последних лет, авторские задачи, рекомендации по литературе', 'http://iloveeconomics.ru/');\n" +
                "INSERT INTO material (id, subject, description, site) VALUES (138, 102, 'Огромную коллекцию олимпиадных заданий по математике', 'http://problems.ru/');\n" +
                "INSERT INTO material (id, subject, description, site) VALUES (139, 81, 'Зализняк А. А. Из заметок о любительской лингвистике', 'https://ru.ru1lib.org/book/3681063/1289b9');\n" +
                "INSERT INTO material (id, subject, description, site) VALUES (140, 81, 'Плунгян В. А. Почему языки такие разные', 'https://ru.ru1lib.org/book/2932462/294899');\n" +
                "INSERT INTO material (id, subject, description, site) VALUES (141, 81, 'Пешковский А. М. Русский синтаксис в научном освещении', 'https://ru.ru1lib.org/book/2573531/c09a55');\n" +
                "INSERT INTO material (id, subject, description, site) VALUES (142, 81, 'Князев С. В., Пожарицкая С. К. Современный русский литературный язык. Фонетика. Графика. Орфография. Орфоэпия', 'https://ru.ru1lib.org/book/3712709/cba846');\n" +
                "INSERT INTO material (id, subject, description, site) VALUES (143, 81, 'Аванта+. Языкознание. Русский язык. Энциклопедия для детей', 'https://ru.ru1lib.org/book/2076305/f84ab9');\n" +
                "INSERT INTO material (id, subject, description, site) VALUES (144, 81, 'Беликов В. И., Муравенко Е. В., Алексеев М. Е. Задачи лингвистических олимпиад', 'https://mccme.ru/llsh/books/olimp-1965-1975/lingv_1965_1975.pdf');\n" +
                "INSERT INTO material (id, subject, description, site) VALUES (145, 81, 'Лекант П. А., Касаткин Л. Л., Клобуков Е. В. Современный русский литературный язык (академический учебник)', 'https://hum.uch-lit.ru/yazyiki-i-yazyikoznanie/lekant-sovremennyj-russkij-yazyk-uchebnik-dlya-akademicheskogo-bakalavriata');\n" +
                "INSERT INTO material (id, subject, description, site) VALUES (146, 81, 'Собрание древнерусских текстов, предназначенных для широкого круга читателей', 'http://lib.pushkinskijdom.ru/Default.aspx?tabid=2070');\n" +
                "INSERT INTO material (id, subject, description, site) VALUES (147, 81, 'Энциклопедия в видео', 'https://postnauka.ru/themes/linguistics');\n" +
                "INSERT INTO material (id, subject, description, site) VALUES (148, 58, 'Гаспаров М. Л. «Снова тучи надо мною…» Методика анализа', 'https://russkayarech.ru/ru/archive/1997-1/9-20');\n" +
                "INSERT INTO material (id, subject, description, site) VALUES (149, 58, 'Лотман Ю. М. Анализ поэтического текста', 'http://blog.zabedu.ru/zubarevamyu/wp-content/uploads/sites/35/2017/01/%D0%9E-%D0%BF%D0%BE%D1%8D%D1%82%D0%B0%D1%85-%D0%B8-%D0%BF%D0%BE%D1%8D%D0%B7%D0%B8%D0%B8.-%D0%90%D0%BD%D0%B0%D0%BB%D0%B8%D0%B7-%D0%BF%D0%BE%D1%8D%D1%82%D0%B8%D1%87%D0%B5%D1%81%D0%BA%D0%BE%D0%B3%D0%BE-%D1%82%D0%B5%D0%BA%D1%81%D1%82%D0%B0_%D0%9B%D0%BE%D1%82%D0%BC%D0%B0%D0%BD_1996.pdf');\n" +
                "INSERT INTO material (id, subject, description, site) VALUES (150, 58, 'Эйхенбаум Б. М. Как сделана «Шинель» Гоголя', 'https://ru.ru1lib.org/book/3073431/431c84');\n" +
                "INSERT INTO material (id, subject, description, site) VALUES (151, 58, 'Шкловский В. Б. Искусство как прием', 'https://ru.ru1lib.org/book/3084981/0a425f');\n" +
                "INSERT INTO material (id, subject, description, site) VALUES (152, 58, 'Хализев В. Е. Теория литературы', 'https://ru.ru1lib.org/book/2369217/b67b15');\n" +
                "INSERT INTO material (id, subject, description, site) VALUES (153, 58, 'Холшевников В. Е. Основы стиховедения', 'https://ru.ru1lib.org/book/3105293/d6340c');\n" +
                "INSERT INTO material (id, subject, description, site) VALUES (154, 58, 'Главный научно-популярный литературоведческий интернет-источник', 'http://arzamas.academy/');\n" +
                "INSERT INTO material (id, subject, description, site) VALUES (155, 58, 'Раздел «Библиотека» на этом сайте предлагает подробный список полезных для олимпиадника-филолога трудов, пособий, учебников и сборников, а также памятки по анализу прозаического и поэтического текста', 'https://sites.google.com/site/vsovershenstve/biblioteka');\n" +
                "INSERT INTO material (id, subject, description, site) VALUES (156, 58, 'Здесь собрана большая подборка заданий филологических олимпиад (раздел «Олимпиады»), а в «Литературоведческом словарике» можно найти статьи в жанре «просто о сложном», понятно объясняющие литературоведческие и культурологические реалии', 'https://slovesnik.org/');\n" +
                "INSERT INTO material (id, subject, description, site) VALUES (157, 58, 'Проект, в котором известный писатель и литературовед Дмитрий Быков предлагает свои интерпретации знаковых произведений русской литературы XX века', 'https://www.youtube.com/playlist?list=PLM7h4jc1fXJc7wHEJ0I3ODuQu421qYgPo');\n" +
                "INSERT INTO material (id, subject, description, site) VALUES (158, 1, 'Латчук В. Н., Марков В. В., Миронов С. К., Вангородский С. Н. Основы безопасности жизнедеятельности', 'https://uchebnik-skachatj-besplatno.com/%D0%9E%D0%91%D0%96/%D0%A3%D1%87%D0%B5%D0%B1%D0%BD%D0%B8%D0%BA%20%D0%9E%D0%91%D0%96%2010%20%D0%BA%D0%BB%D0%B0%D1%81%D1%81%20%D0%9B%D0%B0%D1%82%D1%87%D1%83%D0%BA%20%D0%92%D0%B0%D0%BD%D0%B3%D0%BE%D1%80%D0%BE%D0%B4%D1%81%D0%BA%D0%B8%D0%B9/index.html');\n" +
                "INSERT INTO material (id, subject, description, site) VALUES (159, 1, 'Бубнов В., Бубнова Н. Атлас добровольного спасателя', 'https://sch1015z.mskobr.ru/files/atlas_spasatelya.pdf');\n" +
                "INSERT INTO material (id, subject, description, site) VALUES (160, 1, 'Здесь найти множество памяток, полезных советов, видеоинструкций и правил поведения в чрезвычайных ситуациях', 'http://www.mchs.gov.ru/');\n" +
                "INSERT INTO material (id, subject, description, site) VALUES (161, 1, 'Интернет-ресурс, который познакомит вас с действиями при ЧС и научит оказывать первую помощь', 'http://www.culture.mchs.gov.ru/');\n" +
                "INSERT INTO material (id, subject, description, site) VALUES (162, 1, 'Здесь собраны актуальные данные о самой структуре вооруженных сил, предназначении каждого из видов войск', 'http://mil.ru/');\n" +
                "INSERT INTO material (id, subject, description, site) VALUES (163, 90, 'Орлова Л. В. Азбука моды (девочки)', 'https://ru.ru1lib.org/book/756887/e5f796');\n" +
                "INSERT INTO material (id, subject, description, site) VALUES (164, 90, 'Буровик К. А. Родословная вещей (девочки)', 'https://ru.ru1lib.org/book/5658871/12a455');\n" +
                "INSERT INTO material (id, subject, description, site) VALUES (165, 90, 'Нерсесов Я. Н. Я познаю мир: История моды (девочки)', 'https://knigogid.ru/books/874639-ya-poznayu-mir-istoriya-mody');\n" +
                "INSERT INTO material (id, subject, description, site) VALUES (166, 90, 'Здесь можно узнать о разных способах конструирования одежды (девочки)', 'http://fashion.h19.ru/alman1.htm');\n" +
                "INSERT INTO material (id, subject, description, site) VALUES (167, 90, 'Тут можно найти подробное описание методик кроя одежды, актуальные данные о размерах и маркировках, классификацию и историю различных видов одежды (девочки)', 'http://uni-mecs.com/sections/history_cutting.shtml');\n" +
                "INSERT INTO material (id, subject, description, site) VALUES (168, 90, 'Ботвинников А. Д., Виноградов В. Н., Вышнепольский И. С. Черчение. 9 класс (мальчики)', 'https://11klasov.com/6860-cherchenie-9-klass-a-d-botvinnikov-v-i-vyshnepolskij-v-n-vinogradov.html');\n" +
                "INSERT INTO material (id, subject, description, site) VALUES (169, 90, 'Журнал «Популярная механика» (мальчики)', 'https://www.popmech.ru/');\n" +
                "INSERT INTO material (id, subject, description, site) VALUES (170, 90, 'Серия обучающих видео, которые посвящены работе на различных станках, уходу за оборудованием, правилам поведения в мастерской и многому другому (мальчики)', 'https://www.youtube.com/channel/UCnJSm2aNkvfLsKq2ZSO8oGQ');\n" +
                "INSERT INTO material (id, subject, description, site) VALUES (171, 90, 'Наглядные пособия по самым разнообразным видам прикладного искусства (мальчики)', 'https://www.youtube.com/user/jimmydiresta/featured');\n" +
                "INSERT INTO material (id, subject, description, site) VALUES (172, 90, 'Крупнейшая в мире коллекция DIY (Do It Yourself) проектов с полными пошаговыми инструкциями по изготовлению (мальчики)', 'https://www.instructables.com/');\n" +
                "INSERT INTO material (id, subject, description, site) VALUES (173, 93, 'Каинов А. Н. Физическая культура. 9-11 классы: организация и проведение олимпиад', 'https://www.labirint.ru/books/441809/');\n" +
                "INSERT INTO material (id, subject, description, site) VALUES (174, 93, 'Столбов В. В., Иванов С. А., Родниченко В. С., Константинов А. Т., Кофман Л. Б., Столяров В. И., Смирнов А. М. Твой олимпийский учебник', 'https://knigogid.ru/books/215811-tvoy-olimpiyskiy-uchebnik');\n" +
                "INSERT INTO material (id, subject, description, site) VALUES (175, 93, 'Киселев П. А., Киселева С. Б. Тестовые вопросы и задания по физической культуре', 'https://knigogid.ru/books/1694867-testovye-voprosy-i-zadaniya-po-fizicheskoy-kulture-uchebno-metodicheskoe-posobie');\n" +
                "INSERT INTO material (id, subject, description, site) VALUES (176, 93, 'Паршиков А. Т., Кузин В. В., Виленский М. Я. Физическая культура. 10 класс, 11 класс', 'https://bmu.vrn.muzkult.ru/media/2018/08/02/1225661244/Vilenskij-Fizicheskaya-kultura.pdf');\n" +
                "INSERT INTO material (id, subject, description, site) VALUES (177, 93, 'Никифоров А. А., Середа Н. С. Предметные олимпиады 7-11 классы.Физическая культура', 'https://knigogid.ru/books/195440-poklyanis/toread');\n" +
                "INSERT INTO material (id, subject, description, site) VALUES (178, 41, 'Balea Amalia, Ramos Pilar. Cultura en Espana. B1- B2 (Con soluciones)', 'https://ru.scribd.com/document/363959162/Balea-Amalia-Ramos-Pilar-Cultura-en-Espan-a-B1-B2');\n" +
                "INSERT INTO material (id, subject, description, site) VALUES (179, 41, 'Alzugaray Pilar, Bartolome Paz. Preparacion al diploma espanol. DELE C2 иPerez R., Quintana L. Preparacion al diploma espanol. DELE Nivel C1', 'https://ru.ru1lib.org/book/3029236/6a6ae2');\n" +
                "INSERT INTO material (id, subject, description, site) VALUES (180, 41, 'Gramatica De Uso Del Espanol. Nivel C1-С2. Ramon Palencia, Luis Aragones', 'https://ru.ru1lib.org/book/3019442/550916');\n" +
                "INSERT INTO material (id, subject, description, site) VALUES (181, 41, 'Виноградов В. С. Грамматика испанского языка. Практический курс', 'https://ru.ru1lib.org/book/618501/04a27f');\n" +
                "INSERT INTO material (id, subject, description, site) VALUES (182, 41, 'Патрушев А. И. Учебник испанского языка. Практический курс. Продвинутый этап', 'https://ru.ru1lib.org/book/3025874/8c8a75');\n" +
                "INSERT INTO material (id, subject, description, site) VALUES (183, 41, 'Борисенко И. И. Грамматика испанской разговорной речи с упражнениями. Учебное пособие', 'https://ru.ru1lib.org/book/618502/eb3c4d');\n" +
                "INSERT INTO material (id, subject, description, site) VALUES (184, 41, 'Можно найти много видео по искусству и мини-рецензии тематических фильмов, которые могут помочь в таких разделах, как «Аудирование» и «Письмо»', 'https://www.youtube.com/user/MrVideosyarte/videos');\n" +
                "INSERT INTO material (id, subject, description, site) VALUES (185, 41, 'На сайте много аудиоматериала на испанском языке', 'https://www.ivoox.com/');\n" +
                "INSERT INTO material (id, subject, description, site) VALUES (186, 97, 'Бубнова Г. И. Французский язык. Всероссийские олимпиады', 'https://catalog.prosv.ru/attachment/941fa472-face-11e3-a3fe-0050569c7d18.pdf');\n" +
                "INSERT INTO material (id, subject, description, site) VALUES (187, 97, 'Потушанская Л. Л., Котова Г. М., Шкунаева И. Д. Практический курс французского языка в двух томах', 'https://vk.com/doc194154061_466400721?hash=c6f3919bb2d21b2544&dl=02723def6b9ac53f6a');\n" +
                "INSERT INTO material (id, subject, description, site) VALUES (188, 97, 'Бесплатный учебный «кибер-журнал», содержащий упражнения, тесты и игры для изучения французского языка, а также учебные карты для Преподавателей французского языка как иностранного', 'http://www.bonjourdefrance.com/index/indexgram.htm');\n" +
                "INSERT INTO material (id, subject, description, site) VALUES (189, 97, 'французский еженедельный журнал', 'http://la-conjugaison.nouvelobs.com/exercice/grammaire-0-57.php');\n" +
                "INSERT INTO material (id, subject, description, site) VALUES (190, 74, 'Ростовцева Н. В., Литинский С. В. Теория государства и права', 'https://knigogid.ru/books/215909-teoriya-gosudarstva-i-prava-podgotovka-k-olimpiadam-po-pravu');\n" +
                "INSERT INTO material (id, subject, description, site) VALUES (191, 74, 'Владимирский-Буданов М. Ф. Обзор истории русского права', 'https://ru.ru1lib.org/book/1017144/970005');\n" +
                "INSERT INTO material (id, subject, description, site) VALUES (192, 74, 'Монтескье Ш. Л. О духе законов', 'https://ru.ru1lib.org/book/2935068/74c99e');\n" +
                "INSERT INTO material (id, subject, description, site) VALUES (193, 74, 'Покровский И. А. Основные проблемы гражданского права', 'https://ru.ru1lib.org/book/2896218/627e7e');\n" +
                "INSERT INTO material (id, subject, description, site) VALUES (194, 74, 'Пчелинцева Л. М. Практикум по семейному праву', 'https://ru.ru1lib.org/book/524408/848422');\n" +
                "INSERT INTO material (id, subject, description, site) VALUES (195, 74, 'Консультант – правовая система, содержащая актуальное и историческое законодательство, подборки и статьи', 'http://www.consultant.ru/');\n" +
                "INSERT INTO material (id, subject, description, site) VALUES (196, 74, 'Блоги лучших юристов современности, обсуждение законов, законопроектов, решений судов и проблем профессиональной практики', 'https://zakon.ru/');\n" +
                "INSERT INTO material (id, subject, description, site) VALUES (197, 42, 'Верт Н. История советского государства', 'https://ru.ru1lib.org/book/68685/5b9980');\n" +
                "INSERT INTO material (id, subject, description, site) VALUES (198, 42, 'Александров В. Н. История русского искусства', 'https://ru.ru1lib.org/book/2767770/864a47');\n" +
                "INSERT INTO material (id, subject, description, site) VALUES (199, 42, 'Кириллов В. В. Отечественная история в схемах и таблицах', 'https://ru.ru1lib.org/book/3155669/59e567');\n" +
                "INSERT INTO material (id, subject, description, site) VALUES (200, 42, 'Аудиоверсия «История государства Российского» Н. М. Карамзина', 'https://www.youtube.com/watch?v=YQfgHubxQsg');\n" +
                "INSERT INTO material (id, subject, description, site) VALUES (201, 42, '18 серий, длительностью около 50 минут каждая, детально знакомят зрителя с ходом Великой Отечественной войны', 'https://www.youtube.com/watch?v=hDzq67FM0kg&list=PLhuA9d7RIOdZW5GMDfDzPZSIffFYUogL-&index=2');\n" +
                "INSERT INTO material (id, subject, description, site) VALUES (202, 42, 'Серия роликов, посвященных не только историческим эпохам и государственным деятелям', 'https://www.shm.ru/visit/lektsii/');\n" +
                "INSERT INTO material (id, subject, description, site) VALUES (203, 42, 'Очные лекции, расписание известно на месяц вперед, а ведут их выдающиеся исследователи и учёны', 'https://www.shm.ru/visit/lektsii/lektoriy-istoricheskie-subboty/');\n" +
                "INSERT INTO material (id, subject, description, site) VALUES (204, 42, 'Емкие видео-ролики по различными периодами российской истории', 'https://www.shm.ru/visit/lektsii/lektoriy-istoricheskie-subboty/');\n" +
                "INSERT INTO material (id, subject, description, site) VALUES (205, 42, 'Видеолекции, текстовые материалы и мини-тесты', 'http://arzamas.academy/courses');\n" +
                "INSERT INTO material (id, subject, description, site) VALUES (206, 6, 'J. Thomas Advanced Vocabulary and Idioms', 'https://ru.ru1lib.org/book/3167518/46d5bc');\n" +
                "INSERT INTO material (id, subject, description, site) VALUES (207, 6, 'J. Thomson, A. V. Martinet A Practical English Grammar', 'https://ru.ru1lib.org/book/911512/deb635');\n" +
                "INSERT INTO material (id, subject, description, site) VALUES (208, 6, 'Pauline Cullen, Amanda French The Official Cambridge Guide to IELTS', 'https://ru.ru1lib.org/book/3425609/4089b0');\n" +
                "INSERT INTO material (id, subject, description, site) VALUES (209, 6, 'Nick Kenny, Jacky Newbrook CAE Practice Tests Plus', 'https://ru.ru1lib.org/book/3001654/40f728');\n" +
                "INSERT INTO material (id, subject, description, site) VALUES (210, 6, 'Mark Harrison CPE Practice Tests', 'https://ru.ru1lib.org/book/3008071/96d28a');\n" +
                "INSERT INTO material (id, subject, description, site) VALUES (211, 6, 'Гулов А. П. Олимпиады по английскому языку. Use of English', 'https://nsportal.ru/sites/default/files/2019/06/05/olimpiady_po_angliyskomu_yazyku_dlya_8-11_book_2.pdf');\n" +
                "INSERT INTO material (id, subject, description, site) VALUES (212, 6, 'Michael Vince Advanced Language Practice', 'https://ru.ru1lib.org/book/698355/dc26a7');\n" +
                "INSERT INTO material (id, subject, description, site) VALUES (213, 6, 'Голицынскии? Ю. Б. Great Britain', 'https://ru.ru1lib.org/book/2894517/44294d');\n" +
                "INSERT INTO material (id, subject, description, site) VALUES (214, 6, 'Сериалы с субтитрами', 'https://ororo.tv/en/');\n" +
                "INSERT INTO material (id, subject, description, site) VALUES (215, 40, 'Гомбрих Э. История искусства', 'https://ru.ru1lib.org/book/3623375/1d34b4');\n" +
                "INSERT INTO material (id, subject, description, site) VALUES (216, 40, 'Малая история искусств', 'https://ru.ru1lib.org/book/759186/78073d');\n" +
                "INSERT INTO material (id, subject, description, site) VALUES (217, 40, 'Дмитриева Н. А. Краткая история искусств', 'https://ru.ru1lib.org/book/2550972/57b555');\n" +
                "INSERT INTO material (id, subject, description, site) VALUES (218, 40, 'Виппер Б. Р. Введение в историческое изучение искусства', 'https://ru.ru1lib.org/book/1153368/35468b');\n" +
                "INSERT INTO material (id, subject, description, site) VALUES (219, 40, 'Искусство. Энциклопедия для детей. Том 7', 'https://ru.ru1lib.org/book/3140130/8dca2e');\n" +
                "INSERT INTO material (id, subject, description, site) VALUES (220, 40, 'Козлова Н. П. Русская музыкальная литература', 'https://ru.ru1lib.org/book/2876225/666d27');\n" +
                "INSERT INTO material (id, subject, description, site) VALUES (221, 40, 'Шорникова М. И. Русская музыкальная литература', 'https://ru.ru1lib.org/book/3293828/7d0e24');\n" +
                "INSERT INTO material (id, subject, description, site) VALUES (222, 40, 'Брянцева В. Музыкальная литература зарубежных стран: Учебник для ДМШ: Второй год обучения по предмету', 'https://mdshi.krn.muzkult.ru/media/2018/08/09/1228626208/malinovka_muzlit_zarub_stran.pdf');\n" +
                "INSERT INTO material (id, subject, description, site) VALUES (223, 40, 'Лекции, подкасты, статьи о русском и зарубежном искусстве', 'http://arzamas.academy/');\n" +
                "INSERT INTO material (id, subject, description, site) VALUES (224, 40, 'Раздел «коллекция» на сайтах крупнейших художественных музеев даст достоверную информацию о конкретных памятниках искусства', 'https://www.tretyakovgallery.ru/');\n" +
                "INSERT INTO material (id, subject, description, site) VALUES (225, 40, 'В разделе «коллекция» можно найти работы по разным направлениям', 'https://www.tretyakovgallery.ru/');\n" +
                "INSERT INTO material (id, subject, description, site) VALUES (226, 40, 'Определитель архитектурных стилей', 'https://www.tretyakovgallery.ru/');";


        String q2 = "INSERT INTO olimps (id, name, subjects, level, dates, organisator, place, stages, privileges, site) VALUES (1, '«В начале было Слово...»\n" +
                "', '42 58', 23, '01.10.2020-05.03.2021\n" +
                "', 'Российский православный университет святого Иоанна Богослова\n" +
                "', 'Республиканский олимпиадный центр Министерства образования и науки Республики Татарстан', 'Регистрация, отборочный, финальный\n" +
                "', '-\n" +
                "', 'http://олимп.рпу.рф/');\n" +
                "INSERT INTO olimps (id, name, subjects, level, dates, organisator, place, stages, privileges, site) VALUES (2, '«Наследники Левши»\n" +
                "', 92, 3, 'ноябрь 2020-март 2021\n" +
                "', 'ТГУ, ВГУ, ЮЗГУ, ТГУ, ЛГТУ, ОГУ, ПГУ\n" +
                "', 'Отборочный этап олимпиады «Наследники Левши» по физике планируется проводить по школам в Тульской области и других регионах', 'Отборочный, заключительный\n" +
                "', '\"Победители и призеры (при результатах ЕГЭ выше 75) будут зачисляться на технические направления подготовки и специальности в ТулГУ без вступительных испытаний.\n" +
                "Дипломы заключительного этапа олимпиады рассматриваются как индивидуальные достижения.\"\n" +
                "', 'https://rsr-olymp.ru/tsu.tula.ru/abitur/olimp');\n" +
                "INSERT INTO olimps (id, name, subjects, level, dates, organisator, place, stages, privileges, site) VALUES (3, 'XIII Южно-Российская межрегиональная олимпиада школьников «Архитектура и искусство» по комплексу предметов (рисунок, живопись, композиция, черчение)\n" +
                "', '40 100', 2, '30.10.2020-1.06.2021\n" +
                "', 'Академия архитектуры и искусства ФГАОУ ВО «Южный федеральный университет», г. Ростов-на-Дону, Инженерно-технологическая академия ФГАОУ ВО «Южный федеральный университет», г. Таганрог, Гуманитарно-педагогическая академия (филиал) ФГАОУ ВО «Крымский федеральный университет имени В.И. Вернадского» в г. Ялте, Инженерный институт ФГАОУ ВО «Северо-Кавказский федеральный университет», г. Ставрополь, ФГБОУ ВО «Алтайский государственный университет», г. Барнаул, ФГБОУ ВО «Волгоградский государственный социально-педагогический университет», г. Волгоград, ФГБОУ ВО «Воронежский государственный педагогический университет», г. Воронеж, ФГБОУ ВО «Донской государственный технический университет», г. Ростов-на-Дону, ФГБОУ ВО «Казанский национальный исследовательский технологический университет», г. Казань, ФГБОУ ВО «Московский государственный университет технологий и управления имени К. Г. Разумовского (ПКУ)», г. Москва, ФГБОУ ВО «Нижегородский государственный архитектурно-строительный университет», г. Нижний Новгород, ФГБОУ ВО «Пятигорский государственный университет», г. Пятигорск, ФГБОУ ВО «Юго-Западный государственный университет», г. Курск.\n" +
                "', 'Проводится на более 50 площадках, расположенных в г. Ростове-на-Дону, в населенных пунктах Ростовской области и других регионах РФ', 'Два отборочных, заключительный\n" +
                "', 'Победители и призеры заключительного межрегионального этапа имеют право в течение четырех лет быть приравненными к лицам, успешно прошедшим дополнительные вступительные испытания профильной профессиональной направленности по соответствующему предмету, а также быть зачисленными без вступительных испытаний.\n" +
                "', 'https://www.tyuiu.ru/');\n" +
                "INSERT INTO olimps (id, name, subjects, level, dates, organisator, place, stages, privileges, site) VALUES (4, 'Всероссийская олимпиада по финансовой грамотности, финансовому рынку и защите прав потребителей финансовых услуг\n" +
                "', 96, 3, '01.09.2020-31.03.2021\n" +
                "', 'Институт экономики РАН, АНО ДПО «Институт фондового рынка и управления», Федеральная служба по финансовому мониторингу, Федеральная служба по надзору в сфере защиты прав потребителей и благополучия человека, Общероссийской общественно-государственной детско-юношеской организацией «Российское движение школьников», Центральный Банк Российской Федерации, Общероссийская общественная организация потребителей «Союз потребителей финансовых услуг», Национальный институт финансовых рынков и управления\n" +
                "', '-', 'Отборочный, заключительный\n" +
                "', 'Победители и призеры олимпиады получат льготы при поступлении в лучшие экономические вузы страны.\n" +
                "', 'https://rsr-olymp.ru/www.fin-olimp.ru');\n" +
                "INSERT INTO olimps (id, name, subjects, level, dates, organisator, place, stages, privileges, site) VALUES (5, 'Всероссийская олимпиада учащихся музыкальных колледжей\n" +
                "', '99 33 85 86 63', 23, '01.09.2020-31.03.2021\n" +
                "', 'Нижегородская государственная консерватория (академия) им. М. И. Глинки\n" +
                "', 'Несмотря на сложные эпидемиологические условия, в 2020 году заключительный этап олимпиады был проведен в дистанционном режиме.', 'Отборочный, заключительный\n" +
                "', 'При поступлении в Нижегородскую государственную консерваторию им. М.И. Глинки победители и призеры получают наивысшие баллы по профильным предметам.  Победители и призеры олимпиады по предмету «теория и история музыки» в случае поступления на другие факультеты получают наивысшие баллы на теоретических экзаменах. Призеры по отдельным номинациям по предмету «теория и история музыки» получают преимущество при равных баллах.\n" +
                "', 'https://rsr-olymp.ru/www.nnovcons.ru');\n" +
                "INSERT INTO olimps (id, name, subjects, level, dates, organisator, place, stages, privileges, site) VALUES (6, 'Всероссийская олимпиада школьников «Высшая проба»\n" +
                "', '11 14 22 25 6 97 67 48 104 103 36 42 45 55 59 69 68 73 74 78 81 83 92 94 95 98 102 96', 123, '28.09.2020-09.02.2021\n" +
                "', '-\n" +
                "', 'В 2021 году заключительный этап будет проходить в онлайн формате\n" +
                "', 'Отборочный, заключительный\n" +
                "', 'Победители и призеры получают зачисление без вступительных экзаменов на программы подготовки, соответствующие профильному предмету олимпиады, максимальный балл ЕГЭ по предмету, соответствующему профилю олимпиады. Победители и призеры из невыпускных классов в следующем учебном году получают право принять участие сразу в заключительном этапе.\n" +
                "', 'http://olymp.hse.ru/mmo');\n" +
                "INSERT INTO olimps (id, name, subjects, level, dates, organisator, place, stages, privileges, site) VALUES (7, 'Всероссийская олимпиада школьников «Миссия выполнима. Твое призвание-финансист!»\n" +
                "', '42 59 68 102', 3, '07.12.2020-30.01.2021\n" +
                "', 'Северо-Восточный федеральный университет им. М. К. Аммосова, колледж инфраструктурных технологий, Центр развитых одаренных детей, Северо-Кавказский федеральный университет, Комитет по образованию административного городского округа \"Город Калининград\"\n" +
                "', 'В связи со сложной эпидемиологической обстановкой заключительный этап олимпиады будет проходить в онлайн-формате с помощью системы прокторинга.\n" +
                "', 'Отборочный, заключительный\n" +
                "', 'Выпускники школ при поступлении могут воспользоваться особыми правами. Победители и призеры из невыпускных классов предыдущего учебного года имеют право принять участие сразу в заключительном этапе олимпиады минуя отборочный.Победители и призеры Всероссийской олимпиады \"Миссия выполнима. Твое призвание - финансист!\" имеют возможность получать Грант Президента РФ в размере 20 000 рублей ежемесячно на весь период обучения!\n" +
                "', 'http://www.fa.ru/org/div/gprstm/mission/Pages/Home.aspx');\n" +
                "INSERT INTO olimps (id, name, subjects, level, dates, organisator, place, stages, privileges, site) VALUES (8, 'Всероссийская олимпиада школьников «Нанотехнологии - прорыв в будущее!»\n" +
                "', 65, 1, '20.10.2020-27.03.2021\n" +
                "', 'Организаторами Олимпиады выступают Московский государственный университет имени М.В.Ломоносова и Фонд инфраструктурных и образовательных программ.\n" +
                "', 'МГУ имени М.В.Ломоносова\n" +
                "', 'Отборочный, заключительный\n" +
                "', 'Льготы поступающим определяются правилами Приемных комиссий конкретных ВУЗов и периодически могут изменяться, однако принадлежность олимпиады к первому уровню дает максимально возможный уровень льгот.\n" +
                "', 'http://enanos.nanometer.ru/');\n" +
                "INSERT INTO olimps (id, name, subjects, level, dates, organisator, place, stages, privileges, site) VALUES (9, 'Всероссийская Сеченовская олимпиада школьников\n" +
                "', 11, 3, 'Всероссийская Сеченовская олимпиада школьников\n" +
                "', 'Всероссийская Сеченовская олимпиада школьников\n" +
                "', 'Всероссийская Сеченовская олимпиада школьников\n" +
                "', 'Всероссийская Сеченовская олимпиада школьников\n" +
                "', 'Всероссийская Сеченовская олимпиада школьников\n" +
                "', 'https://www.sechenov.ru/univers/structure/facultie/dovuz/olimpiady/');\n" +
                "INSERT INTO olimps (id, name, subjects, level, dates, organisator, place, stages, privileges, site) VALUES (10, 'Всероссийская Толстовская олимпиада школьников\n" +
                "', '42 68 58', 23, 'Всероссийская Толстовская олимпиада школьников\n" +
                "', 'Всероссийская Толстовская олимпиада школьников\n" +
                "', 'Всероссийская Толстовская олимпиада школьников\n" +
                "', 'Всероссийская Толстовская олимпиада школьников\n" +
                "', 'Всероссийская Толстовская олимпиада школьников\n" +
                "', 'http://tsput.ru/olympiad/');\n" +
                "INSERT INTO olimps (id, name, subjects, level, dates, organisator, place, stages, privileges, site) VALUES (11, 'Всероссийская экономическая олимпиада школьников имени Н.Д. Кондратьева\n" +
                "', 102, 1, 'Всероссийская экономическая олимпиада школьников имени Н.Д. Кондратьева\n" +
                "', 'Всероссийская экономическая олимпиада школьников имени Н.Д. Кондратьева\n" +
                "', 'Всероссийская экономическая олимпиада школьников имени Н.Д. Кондратьева\n" +
                "', 'Всероссийская экономическая олимпиада школьников имени Н.Д. Кондратьева\n" +
                "', 'Всероссийская экономическая олимпиада школьников имени Н.Д. Кондратьева\n" +
                "', 'https://rsr-olymp.ru/www.olimpiada-kondratiev.ru');\n" +
                "INSERT INTO olimps (id, name, subjects, level, dates, organisator, place, stages, privileges, site) VALUES (12, 'Всероссийский конкурс научных работ школьников «Юниор»\n" +
                "', '30 23', 23, 'Всероссийский конкурс научных работ школьников «Юниор»\n" +
                "', 'Всероссийский конкурс научных работ школьников «Юниор»\n" +
                "', 'Всероссийский конкурс научных работ школьников «Юниор»\n" +
                "', 'Всероссийский конкурс научных работ школьников «Юниор»\n" +
                "', 'Всероссийский конкурс научных работ школьников «Юниор»\n" +
                "', 'https://admission.mephi.ru/olympiads/junior');";
        String q4 =
                "INSERT INTO olimps (id, name, subjects, level, dates, organisator, place, stages, privileges, site) VALUES (13, 'Всесибирская открытая олимпиада школьников\n" +
                        "', '8 11 36 59 92 98', 123, 'Всесибирская открытая олимпиада школьников\n" +
                        "', 'Всесибирская открытая олимпиада школьников\n" +
                        "', 'Всесибирская открытая олимпиада школьников\n" +
                        "', 'Всесибирская открытая олимпиада школьников\n" +
                        "', 'Всесибирская открытая олимпиада школьников\n" +
                        "', 'http://sesc.nsu.ru/vsesib/');\n" +
                        "INSERT INTO olimps (id, name, subjects, level, dates, organisator, place, stages, privileges, site) VALUES (14, 'Вузовско-академическая олимпиада по программированию на Урале\n" +
                        "', 76, 3, 'Вузовско-академическая олимпиада по программированию на Урале\n" +
                        "', 'Вузовско-академическая олимпиада по программированию на Урале\n" +
                        "', 'Вузовско-академическая олимпиада по программированию на Урале\n" +
                        "', 'Вузовско-академическая олимпиада по программированию на Урале\n" +
                        "', 'Вузовско-академическая олимпиада по программированию на Урале\n" +
                        "', 'https://sp.urfu.ru/');\n" +
                        "INSERT INTO olimps (id, name, subjects, level, dates, organisator, place, stages, privileges, site) VALUES (15, 'Герценовская олимпиада школьников\n" +
                        "', '17 6 97 41 67', 2, 'Герценовская олимпиада школьников\n" +
                        "', 'Герценовская олимпиада школьников\n" +
                        "', 'Герценовская олимпиада школьников\n" +
                        "', 'Герценовская олимпиада школьников\n" +
                        "', 'Герценовская олимпиада школьников\n" +
                        "', 'https://www.herzen.spb.ru/abiturients/olymp_for_high_school_students');\n" +
                        "INSERT INTO olimps (id, name, subjects, level, dates, organisator, place, stages, privileges, site) VALUES (16, 'Городская открытая олимпиада школьников по физике\n" +
                        "', 92, 2, 'Городская открытая олимпиада школьников по физике\n" +
                        "', 'Городская открытая олимпиада школьников по физике\n" +
                        "', 'Городская открытая олимпиада школьников по физике\n" +
                        "', 'Городская открытая олимпиада школьников по физике\n" +
                        "', 'Городская открытая олимпиада школьников по физике\n" +
                        "', 'http://physolymp.spb.ru/');\n" +
                        "INSERT INTO olimps (id, name, subjects, level, dates, organisator, place, stages, privileges, site) VALUES (17, 'Государственный аудит\n" +
                        "', 68, 2, 'Государственный аудит\n" +
                        "', 'Государственный аудит\n" +
                        "', 'Государственный аудит\n" +
                        "', 'Государственный аудит\n" +
                        "', 'Государственный аудит\n" +
                        "', 'http://olimp.audit.msu.ru/');\n" +
                        "INSERT INTO olimps (id, name, subjects, level, dates, organisator, place, stages, privileges, site) VALUES (18, 'Инженерная олимпиада школьников\n" +
                        "', 92, 2, 'Инженерная олимпиада школьников\n" +
                        "', 'Инженерная олимпиада школьников\n" +
                        "', 'Инженерная олимпиада школьников\n" +
                        "', 'Инженерная олимпиада школьников\n" +
                        "', 'Инженерная олимпиада школьников\n" +
                        "', 'http://olimp.audit.msu.ru/');\n" +
                        "INSERT INTO olimps (id, name, subjects, level, dates, organisator, place, stages, privileges, site) VALUES (19, 'Интернет-олимпиада школьников по физике\n" +
                        "', 92, 2, 'Интернет-олимпиада школьников по физике\n" +
                        "', 'Интернет-олимпиада школьников по физике\n" +
                        "', 'Интернет-олимпиада школьников по физике\n" +
                        "', 'Интернет-олимпиада школьников по физике\n" +
                        "', 'Интернет-олимпиада школьников по физике\n" +
                        "', 'http://distolymp2.spbu.ru/');\n" +
                        "INSERT INTO olimps (id, name, subjects, level, dates, organisator, place, stages, privileges, site) VALUES (20, 'Кутафинская олимпиада школьников по праву\n" +
                        "', 74, 2, 'Кутафинская олимпиада школьников по праву\n" +
                        "', 'Кутафинская олимпиада школьников по праву\n" +
                        "', 'Кутафинская олимпиада школьников по праву\n" +
                        "', 'Кутафинская олимпиада школьников по праву\n" +
                        "', 'Кутафинская олимпиада школьников по праву\n" +
                        "', 'http://msal.ru/');\n" +
                        "INSERT INTO olimps (id, name, subjects, level, dates, organisator, place, stages, privileges, site) VALUES (21, 'Межвузовская олимпиада школьников «Первый успех»\n" +
                        "', 71, 2, 'Межвузовская олимпиада школьников «Первый успех»\n" +
                        "', 'Межвузовская олимпиада школьников «Первый успех»\n" +
                        "', 'Межвузовская олимпиада школьников «Первый успех»\n" +
                        "', 'Межвузовская олимпиада школьников «Первый успех»\n" +
                        "', 'Межвузовская олимпиада школьников «Первый успех»\n" +
                        "', 'https://www.herzen.spb.ru/abiturients/olymp_for_high_school_students/1_uspeh/');\n" +
                        "INSERT INTO olimps (id, name, subjects, level, dates, organisator, place, stages, privileges, site) VALUES (22, 'Междисциплинарная олимпиада школьников имени В.И. Вернадского\n" +
                        "', '42 68', 2, 'Междисциплинарная олимпиада школьников имени В.И. Вернадского\n" +
                        "', 'Междисциплинарная олимпиада школьников имени В.И. Вернадского\n" +
                        "', 'Междисциплинарная олимпиада школьников имени В.И. Вернадского\n" +
                        "', 'Междисциплинарная олимпиада школьников имени В.И. Вернадского\n" +
                        "', 'Междисциплинарная олимпиада школьников имени В.И. Вернадского\n" +
                        "', 'https://rsr-olymp.ru/vernadsky.online');\n" +
                        "INSERT INTO olimps (id, name, subjects, level, dates, organisator, place, stages, privileges, site) VALUES (23, 'Международная олимпиада школьников «Искусство графики»\n" +
                        "', '79 20', 1, 'Международная олимпиада школьников «Искусство графики»\n" +
                        "', 'Международная олимпиада школьников «Искусство графики»\n" +
                        "', 'Международная олимпиада школьников «Искусство графики»\n" +
                        "', 'Международная олимпиада школьников «Искусство графики»\n" +
                        "', 'Международная олимпиада школьников «Искусство графики»\n" +
                        "', 'https://old.mospolytech.ru/index.php?id=6574');\n" +
                        "INSERT INTO olimps (id, name, subjects, level, dates, organisator, place, stages, privileges, site) VALUES (24, 'Межрегиональная олимпиада по праву «ФЕМИДА»\n" +
                        "', 74, 2, 'Межрегиональная олимпиада по праву «ФЕМИДА»\n" +
                        "', 'Межрегиональная олимпиада по праву «ФЕМИДА»\n" +
                        "', 'Межрегиональная олимпиада по праву «ФЕМИДА»\n" +
                        "', 'Межрегиональная олимпиада по праву «ФЕМИДА»\n" +
                        "', 'Межрегиональная олимпиада по праву «ФЕМИДА»\n" +
                        "', 'https://rsr-olymp.ru/www.rgup.ru/olimp');\n" +
                        "INSERT INTO olimps (id, name, subjects, level, dates, organisator, place, stages, privileges, site) VALUES (25, 'Межрегиональная олимпиада школьников «САММАТ»\n" +
                        "', 59, 2, 'Межрегиональная олимпиада школьников «САММАТ»\n" +
                        "', 'Межрегиональная олимпиада школьников «САММАТ»\n" +
                        "', 'Межрегиональная олимпиада школьников «САММАТ»\n" +
                        "', 'Межрегиональная олимпиада школьников «САММАТ»\n" +
                        "', 'Межрегиональная олимпиада школьников «САММАТ»\n" +
                        "', 'https://sammat.samgtu.ru/sammat');\n" +
                        "INSERT INTO olimps (id, name, subjects, level, dates, organisator, place, stages, privileges, site) VALUES (26, 'Межрегиональная олимпиада школьников «Архитектура и искусство» по комплексу предметов (рисунок, композиция)\n" +
                        "', 40, 3, 'Межрегиональная олимпиада школьников «Архитектура и искусство» по комплексу предметов (рисунок, композиция)\n" +
                        "', 'Межрегиональная олимпиада школьников «Архитектура и искусство» по комплексу предметов (рисунок, композиция)\n" +
                        "', 'Межрегиональная олимпиада школьников «Архитектура и искусство» по комплексу предметов (рисунок, композиция)\n" +
                        "', 'Межрегиональная олимпиада школьников «Архитектура и искусство» по комплексу предметов (рисунок, композиция)\n" +
                        "', 'Межрегиональная олимпиада школьников «Архитектура и искусство» по комплексу предметов (рисунок, композиция)\n" +
                        "', 'https://www.tyuiu.ru/');\n" +
                        "INSERT INTO olimps (id, name, subjects, level, dates, organisator, place, stages, privileges, site) VALUES (27, 'Межрегиональная олимпиада школьников «Будущие исследователи - будущее науки»\n" +
                        "', '11 42 59 81 92 98', 2, 'Межрегиональная олимпиада школьников «Будущие исследователи - будущее науки»\n" +
                        "', 'Межрегиональная олимпиада школьников «Будущие исследователи - будущее науки»\n" +
                        "', 'Межрегиональная олимпиада школьников «Будущие исследователи - будущее науки»\n" +
                        "', 'Межрегиональная олимпиада школьников «Будущие исследователи - будущее науки»\n" +
                        "', 'Межрегиональная олимпиада школьников «Будущие исследователи - будущее науки»\n" +
                        "', 'http://www.unn.ru/bibn/');\n" +
                        "INSERT INTO olimps (id, name, subjects, level, dates, organisator, place, stages, privileges, site) VALUES (28, 'Межрегиональная олимпиада школьников «Евразийская лингвистическая олимпиада»\n" +
                        "', '6 97 41 67', 23, 'Межрегиональная олимпиада школьников «Евразийская лингвистическая олимпиада»\n" +
                        "', 'Межрегиональная олимпиада школьников «Евразийская лингвистическая олимпиада»\n" +
                        "', 'Межрегиональная олимпиада школьников «Евразийская лингвистическая олимпиада»\n" +
                        "', 'Межрегиональная олимпиада школьников «Евразийская лингвистическая олимпиада»\n" +
                        "', 'Межрегиональная олимпиада школьников «Евразийская лингвистическая олимпиада»\n" +
                        "', 'http://linguanet.ru/Solimpiada/');\n" +
                        "INSERT INTO olimps (id, name, subjects, level, dates, organisator, place, stages, privileges, site) VALUES (29, 'Межрегиональная олимпиада школьников им. В.Е.Татлина\n" +
                        "', '79 51 19', 2, 'Межрегиональная олимпиада школьников им. В.Е.Татлина\n" +
                        "', 'Межрегиональная олимпиада школьников им. В.Е.Татлина\n" +
                        "', 'Межрегиональная олимпиада школьников им. В.Е.Татлина\n" +
                        "', 'Межрегиональная олимпиада школьников им. В.Е.Татлина\n" +
                        "', 'Межрегиональная олимпиада школьников им. В.Е.Татлина\n" +
                        "', 'https://rsr-olymp.ru/pguas.ru');\n" +
                        "INSERT INTO olimps (id, name, subjects, level, dates, organisator, place, stages, privileges, site) VALUES (30, 'Межрегиональная олимпиада школьников им. И.Я. Верченко\n" +
                        "', '52 59', 2, 'Межрегиональная олимпиада школьников им. И.Я. Верченко\n" +
                        "', 'Межрегиональная олимпиада школьников им. И.Я. Верченко\n" +
                        "', 'Межрегиональная олимпиада школьников им. И.Я. Верченко\n" +
                        "', 'Межрегиональная олимпиада школьников им. И.Я. Верченко\n" +
                        "', 'Межрегиональная олимпиада школьников им. И.Я. Верченко\n" +
                        "', 'https://rsr-olymp.ru/www.v-olymp.ru');\n" +
                        "INSERT INTO olimps (id, name, subjects, level, dates, organisator, place, stages, privileges, site) VALUES (31, 'Межрегиональная олимпиада школьников на базе ведомственных образовательных организаций\n" +
                        "', '6 97 41 67 48 59 68 92', 23, 'Межрегиональная олимпиада школьников на базе ведомственных образовательных организаций\n" +
                        "', 'Межрегиональная олимпиада школьников на базе ведомственных образовательных организаций\n" +
                        "', 'Межрегиональная олимпиада школьников на базе ведомственных образовательных организаций\n" +
                        "', 'Межрегиональная олимпиада школьников на базе ведомственных образовательных организаций\n" +
                        "', 'Межрегиональная олимпиада школьников на базе ведомственных образовательных организаций\n" +
                        "', 'https://rsr-olymp.ru/www.v-olymp.ru');\n" +
                        "INSERT INTO olimps (id, name, subjects, level, dates, organisator, place, stages, privileges, site) VALUES (32, 'Межрегиональная отраслевая олимпиада школьников «Паруса надежды»\n" +
                        "', '59 87', 23, 'Межрегиональная отраслевая олимпиада школьников «Паруса надежды»\n" +
                        "', 'Межрегиональная отраслевая олимпиада школьников «Паруса надежды»\n" +
                        "', 'Межрегиональная отраслевая олимпиада школьников «Паруса надежды»\n" +
                        "', 'Межрегиональная отраслевая олимпиада школьников «Паруса надежды»\n" +
                        "', 'Межрегиональная отраслевая олимпиада школьников «Паруса надежды»\n" +
                        "', 'https://rsr-olymp.ru/rut-miit.ru');\n" +
                        "INSERT INTO olimps (id, name, subjects, level, dates, organisator, place, stages, privileges, site) VALUES (33, 'Межрегиональные предметные олимпиады федерального государственного автономного образовательного учреждения высшего образования «Казанский (Приволжский) федеральный университет»\n" +
                        "', '6 92 98', 3, 'Межрегиональные предметные олимпиады федерального государственного автономного образовательного учреждения высшего образования «Казанский (Приволжский) федеральный университет»\n" +
                        "', 'Межрегиональные предметные олимпиады федерального государственного автономного образовательного учреждения высшего образования «Казанский (Приволжский) федеральный университет»\n" +
                        "', 'Межрегиональные предметные олимпиады федерального государственного автономного образовательного учреждения высшего образования «Казанский (Приволжский) федеральный университет»\n" +
                        "', 'Межрегиональные предметные олимпиады федерального государственного автономного образовательного учреждения высшего образования «Казанский (Приволжский) федеральный университет»\n" +
                        "', 'Межрегиональные предметные олимпиады федерального государственного автономного образовательного учреждения высшего образования «Казанский (Приволжский) федеральный университет»\n" +
                        "', 'https://admissions.kpfu.ru/mpo');\n" +
                        "INSERT INTO olimps (id, name, subjects, level, dates, organisator, place, stages, privileges, site) VALUES (34, 'Межрегиональный экономический фестиваль школьников «Сибириада. Шаг в мечту»\n" +
                        "', 102, 23, 'Межрегиональный экономический фестиваль школьников «Сибириада. Шаг в мечту»\n" +
                        "', 'Межрегиональный экономический фестиваль школьников «Сибириада. Шаг в мечту»\n" +
                        "', 'Межрегиональный экономический фестиваль школьников «Сибириада. Шаг в мечту»\n" +
                        "', 'Межрегиональный экономический фестиваль школьников «Сибириада. Шаг в мечту»\n" +
                        "', 'Межрегиональный экономический фестиваль школьников «Сибириада. Шаг в мечту»\n" +
                        "', 'http://sibiriada.org/');\n" +
                        "INSERT INTO olimps (id, name, subjects, level, dates, organisator, place, stages, privileges, site) VALUES (35, 'Многопредметная олимпиада «Юные таланты»\n" +
                        "', '17 18 98', 2, 'Многопредметная олимпиада «Юные таланты»\n" +
                        "', 'Многопредметная олимпиада «Юные таланты»\n" +
                        "', 'Многопредметная олимпиада «Юные таланты»\n" +
                        "', 'Многопредметная олимпиада «Юные таланты»\n" +
                        "', 'Многопредметная олимпиада «Юные таланты»\n" +
                        "', 'http://olymp.psu.ru/');\n" +
                        "INSERT INTO olimps (id, name, subjects, level, dates, organisator, place, stages, privileges, site) VALUES (36, 'Многопрофильная инженерная олимпиада «Звезда»\n" +
                        "', '23 87', 13, 'Многопрофильная инженерная олимпиада «Звезда»\n" +
                        "', 'Многопрофильная инженерная олимпиада «Звезда»\n" +
                        "', 'Многопрофильная инженерная олимпиада «Звезда»\n" +
                        "', 'Многопрофильная инженерная олимпиада «Звезда»\n" +
                        "', 'Многопрофильная инженерная олимпиада «Звезда»\n" +
                        "', 'http://olymp.psu.ru/');\n" +
                        "INSERT INTO olimps (id, name, subjects, level, dates, organisator, place, stages, privileges, site) VALUES (37, 'Многопрофильная олимпиада школьников Уральского федерального университета «Изумруд»\n" +
                        "', '42 59 68 73 83 81 92', 23, 'Многопрофильная олимпиада школьников Уральского федерального университета «Изумруд»\n" +
                        "', 'Многопрофильная олимпиада школьников Уральского федерального университета «Изумруд»\n" +
                        "', 'Многопрофильная олимпиада школьников Уральского федерального университета «Изумруд»\n" +
                        "', 'Многопрофильная олимпиада школьников Уральского федерального университета «Изумруд»\n" +
                        "', 'Многопрофильная олимпиада школьников Уральского федерального университета «Изумруд»\n" +
                        "', 'https://izumrud.urfu.ru/');\n" +
                        "INSERT INTO olimps (id, name, subjects, level, dates, organisator, place, stages, privileges, site) VALUES (38, 'Московская олимпиада школьников\n" +
                        "', '8 15 17 36 43 26 42 59 80 68 74 57 94 92 75 98 102 96', 3, 'Московская олимпиада школьников\n" +
                        "', 'Московская олимпиада школьников\n" +
                        "', 'Московская олимпиада школьников\n" +
                        "', 'Московская олимпиада школьников\n" +
                        "', 'Московская олимпиада школьников\n" +
                        "', 'http://predprof.olimpiada.ru/');\n" +
                        "INSERT INTO olimps (id, name, subjects, level, dates, organisator, place, stages, privileges, site) VALUES (39, 'Общероссийская олимпиада школьников «Основы православной культуры»\n" +
                        "', 70, 123, 'Общероссийская олимпиада школьников «Основы православной культуры»\n" +
                        "', 'Общероссийская олимпиада школьников «Основы православной культуры»\n" +
                        "', 'Общероссийская олимпиада школьников «Основы православной культуры»\n" +
                        "', 'Общероссийская олимпиада школьников «Основы православной культуры»\n" +
                        "', 'Общероссийская олимпиада школьников «Основы православной культуры»\n" +
                        "', 'http://www.pravolimp.ru/');\n" +
                        "INSERT INTO olimps (id, name, subjects, level, dates, organisator, place, stages, privileges, site) VALUES (40, 'Объединённая межвузовская математическая олимпиада школьников\n" +
                        "', 59, 2, 'Объединённая межвузовская математическая олимпиада школьников\n" +
                        "', 'Объединённая межвузовская математическая олимпиада школьников\n" +
                        "', 'Объединённая межвузовская математическая олимпиада школьников\n" +
                        "', 'Объединённая межвузовская математическая олимпиада школьников\n" +
                        "', 'Объединённая межвузовская математическая олимпиада школьников\n" +
                        "', 'http://olympiads.mccme.ru/ommo/');";
        String q5 =
                "INSERT INTO olimps (id, name, subjects, level, dates, organisator, place, stages, privileges, site) VALUES (41, 'Объединённая международная математическая олимпиада «Формула Единства» / «Третье тысячелетие»\n" +
                        "', '59 92', 2, 'Объединённая международная математическая олимпиада «Формула Единства» / «Третье тысячелетие»\n" +
                        "', 'Объединённая международная математическая олимпиада «Формула Единства» / «Третье тысячелетие»\n" +
                        "', 'Объединённая международная математическая олимпиада «Формула Единства» / «Третье тысячелетие»\n" +
                        "', 'Объединённая международная математическая олимпиада «Формула Единства» / «Третье тысячелетие»\n" +
                        "', 'Объединённая международная математическая олимпиада «Формула Единства» / «Третье тысячелетие»\n" +
                        "', 'https://www.formulo.org/ru/olymp/');\n" +
                        "INSERT INTO olimps (id, name, subjects, level, dates, organisator, place, stages, privileges, site) VALUES (42, 'Океан знаний\n" +
                        "', '42 68 81', 23, 'Океан знаний\n" +
                        "', 'Океан знаний\n" +
                        "', 'Океан знаний\n" +
                        "', 'Океан знаний\n" +
                        "', 'Океан знаний\n" +
                        "', 'https://www.formulo.org/ru/olymp/');\n" +
                        "INSERT INTO olimps (id, name, subjects, level, dates, organisator, place, stages, privileges, site) VALUES (43, 'Олимпиада Кружкового движения Национальной технологической инициативы\n" +
                        "', '77 91 12 9 34 10 89 35 39 37 2 50 29 5 13 66 72 84 64 3 56 16', 3, 'Олимпиада Кружкового движения Национальной технологической инициативы\n" +
                        "', 'Олимпиада Кружкового движения Национальной технологической инициативы\n" +
                        "', 'Олимпиада Кружкового движения Национальной технологической инициативы\n" +
                        "', 'Олимпиада Кружкового движения Национальной технологической инициативы\n" +
                        "', 'Олимпиада Кружкового движения Национальной технологической инициативы\n" +
                        "', 'http://nti-contest.ru/');\n" +
                        "INSERT INTO olimps (id, name, subjects, level, dates, organisator, place, stages, privileges, site) VALUES (44, 'Олимпиада Курчатов\n" +
                        "', '59 92', 123, 'Олимпиада Курчатов\n" +
                        "', 'Олимпиада Курчатов\n" +
                        "', 'Олимпиада Курчатов\n" +
                        "', 'Олимпиада Курчатов\n" +
                        "', 'Олимпиада Курчатов\n" +
                        "', 'http://olimpiadakurchatov.ru/');\n" +
                        "INSERT INTO olimps (id, name, subjects, level, dates, organisator, place, stages, privileges, site) VALUES (45, 'Олимпиада МГИМО МИД России для школьников\n" +
                        "', '42 68', 2, 'Олимпиада МГИМО МИД России для школьников\n" +
                        "', 'Олимпиада МГИМО МИД России для школьников\n" +
                        "', 'Олимпиада МГИМО МИД России для школьников\n" +
                        "', 'Олимпиада МГИМО МИД России для школьников\n" +
                        "', 'Олимпиада МГИМО МИД России для школьников\n" +
                        "', 'https://olymp.mgimo.ru/');\n" +
                        "INSERT INTO olimps (id, name, subjects, level, dates, organisator, place, stages, privileges, site) VALUES (46, 'Олимпиада по комплексу предметов «Культура и искусство»\n" +
                        "', '88 4 24 51 44', 2, 'Олимпиада по комплексу предметов «Культура и искусство»\n" +
                        "', 'Олимпиада по комплексу предметов «Культура и искусство»\n" +
                        "', 'Олимпиада по комплексу предметов «Культура и искусство»\n" +
                        "', 'Олимпиада по комплексу предметов «Культура и искусство»\n" +
                        "', 'Олимпиада по комплексу предметов «Культура и искусство»\n" +
                        "', 'https://olymp.mgimo.ru/');\n" +
                        "INSERT INTO olimps (id, name, subjects, level, dates, organisator, place, stages, privileges, site) VALUES (47, 'Олимпиада РГГУ для школьников\n" +
                        "', '6 97 67 42 58 81', 1, 'Олимпиада РГГУ для школьников\n" +
                        "', 'Олимпиада РГГУ для школьников\n" +
                        "', 'Олимпиада РГГУ для школьников\n" +
                        "', 'Олимпиада РГГУ для школьников\n" +
                        "', 'Олимпиада РГГУ для школьников\n" +
                        "', 'https://rsr-olymp.ru/www.rggu.ru');\n" +
                        "INSERT INTO olimps (id, name, subjects, level, dates, organisator, place, stages, privileges, site) VALUES (48, 'Олимпиада Университета Иннополис «Innopolis Open»\n" +
                        "', '36 59', 2, 'Олимпиада Университета Иннополис «Innopolis Open»\n" +
                        "', 'Олимпиада Университета Иннополис «Innopolis Open»\n" +
                        "', 'Олимпиада Университета Иннополис «Innopolis Open»\n" +
                        "', 'Олимпиада Университета Иннополис «Innopolis Open»\n" +
                        "', 'Олимпиада Университета Иннополис «Innopolis Open»\n" +
                        "', 'http://olymp.innopolis.ru/ooui/');\n" +
                        "INSERT INTO olimps (id, name, subjects, level, dates, organisator, place, stages, privileges, site) VALUES (49, 'Олимпиада школьников «Гранит науки»\n" +
                        "', '36 23 98', 23, 'Олимпиада школьников «Гранит науки»\n" +
                        "', 'Олимпиада школьников «Гранит науки»\n" +
                        "', 'Олимпиада школьников «Гранит науки»\n" +
                        "', 'Олимпиада школьников «Гранит науки»\n" +
                        "', 'Олимпиада школьников «Гранит науки»\n" +
                        "', 'http://ogn.spmi.ru/');\n" +
                        "INSERT INTO olimps (id, name, subjects, level, dates, organisator, place, stages, privileges, site) VALUES (50, 'Олимпиада школьников «Ломоносов»\n" +
                        "', '11 17 18 25 6 97 67 36 73 61 42 46 58 59 95 68 101 78 81 92 30 54 62 80 98 74', 23, 'Олимпиада школьников «Ломоносов»\n" +
                        "', 'Олимпиада школьников «Ломоносов»\n" +
                        "', 'Олимпиада школьников «Ломоносов»\n" +
                        "', 'Олимпиада школьников «Ломоносов»\n" +
                        "', 'Олимпиада школьников «Ломоносов»\n" +
                        "', 'https://rsr-olymp.ru/olymp.msu.ru');\n" +
                        "INSERT INTO olimps (id, name, subjects, level, dates, organisator, place, stages, privileges, site) VALUES (51, 'Олимпиада школьников «Надежда энергетики»\n" +
                        "', '36 92 49', 123, 'Олимпиада школьников «Надежда энергетики»\n" +
                        "', 'Олимпиада школьников «Надежда энергетики»\n" +
                        "', 'Олимпиада школьников «Надежда энергетики»\n" +
                        "', 'Олимпиада школьников «Надежда энергетики»\n" +
                        "', 'Олимпиада школьников «Надежда энергетики»\n" +
                        "', 'http://www.energy-hope.ru/');\n" +
                        "INSERT INTO olimps (id, name, subjects, level, dates, organisator, place, stages, privileges, site) VALUES (52, 'Олимпиада школьников «Покори Воробьёвы горы!»\n" +
                        "', '11 17 25 6 97 67 42 58 59 68 92', 3, 'Олимпиада школьников «Покори Воробьёвы горы!»\n" +
                        "', 'Олимпиада школьников «Покори Воробьёвы горы!»\n" +
                        "', 'Олимпиада школьников «Покори Воробьёвы горы!»\n" +
                        "', 'Олимпиада школьников «Покори Воробьёвы горы!»\n" +
                        "', 'Олимпиада школьников «Покори Воробьёвы горы!»\n" +
                        "', 'https://rsr-olymp.ru/pvg.mk.ru');\n" +
                        "INSERT INTO olimps (id, name, subjects, level, dates, organisator, place, stages, privileges, site) VALUES (53, 'Олимпиада школьников «Робофест»\n" +
                        "', 92, 12, 'Олимпиада школьников «Робофест»\n" +
                        "', 'Олимпиада школьников «Робофест»\n" +
                        "', 'Олимпиада школьников «Робофест»\n" +
                        "', 'Олимпиада школьников «Робофест»\n" +
                        "', 'Олимпиада школьников «Робофест»\n" +
                        "', 'https://rsr-olymp.ru/pvg.mk.ru');\n" +
                        "INSERT INTO olimps (id, name, subjects, level, dates, organisator, place, stages, privileges, site) VALUES (54, 'Олимпиада школьников «Физтех»\n" +
                        "', '11 59 92', 2, 'Олимпиада школьников «Физтех»\n" +
                        "', 'Олимпиада школьников «Физтех»\n" +
                        "', 'Олимпиада школьников «Физтех»\n" +
                        "', 'Олимпиада школьников «Физтех»\n" +
                        "', 'Олимпиада школьников «Физтех»\n" +
                        "', 'https://rsr-olymp.ru/olymp.mipt.ru');\n" +
                        "INSERT INTO olimps (id, name, subjects, level, dates, organisator, place, stages, privileges, site) VALUES (55, 'Олимпиада школьников «Шаг в будущее»\n" +
                        "', '76 59 28 53 92', 123, 'Олимпиада школьников «Шаг в будущее»\n" +
                        "', 'Олимпиада школьников «Шаг в будущее»\n" +
                        "', 'Олимпиада школьников «Шаг в будущее»\n" +
                        "', 'Олимпиада школьников «Шаг в будущее»\n" +
                        "', 'Олимпиада школьников «Шаг в будущее»\n" +
                        "', 'https://rsr-olymp.ru/olymp.bmstu.ru');\n" +
                        "INSERT INTO olimps (id, name, subjects, level, dates, organisator, place, stages, privileges, site) VALUES (56, 'Олимпиада школьников по информатике и программированию\n" +
                        "', 36, 23, 'Олимпиада школьников по информатике и программированию\n" +
                        "', 'Олимпиада школьников по информатике и программированию\n" +
                        "', 'Олимпиада школьников по информатике и программированию\n" +
                        "', 'Олимпиада школьников по информатике и программированию\n" +
                        "', 'Олимпиада школьников по информатике и программированию\n" +
                        "', 'http://neerc.ifmo.ru/school/io');\n" +
                        "INSERT INTO olimps (id, name, subjects, level, dates, organisator, place, stages, privileges, site) VALUES (57, 'Олимпиада школьников по программированию «ТехноКубок»\n" +
                        "', 36, 1, 'Олимпиада школьников по программированию «ТехноКубок»\n" +
                        "', 'Олимпиада школьников по программированию «ТехноКубок»\n" +
                        "', 'Олимпиада школьников по программированию «ТехноКубок»\n" +
                        "', 'Олимпиада школьников по программированию «ТехноКубок»\n" +
                        "', 'Олимпиада школьников по программированию «ТехноКубок»\n" +
                        "', 'https://technocup.mail.ru/');\n" +
                        "INSERT INTO olimps (id, name, subjects, level, dates, organisator, place, stages, privileges, site) VALUES (58, 'Олимпиада Российской академии народного хозяйства и государственной службы при Президенте Российской Федерации\n" +
                        "', '6 48 25 42 68 73 102', 1, 'Олимпиада Российской академии народного хозяйства и государственной службы при Президенте Российской Федерации\n" +
                        "', 'Олимпиада Российской академии народного хозяйства и государственной службы при Президенте Российской Федерации\n" +
                        "', 'Олимпиада Российской академии народного хозяйства и государственной службы при Президенте Российской Федерации\n" +
                        "', 'Олимпиада Российской академии народного хозяйства и государственной службы при Президенте Российской Федерации\n" +
                        "', 'Олимпиада Российской академии народного хозяйства и государственной службы при Президенте Российской Федерации\n" +
                        "', 'https://technocup.mail.ru/');\n" +
                        "INSERT INTO olimps (id, name, subjects, level, dates, organisator, place, stages, privileges, site) VALUES (59, 'Олимпиада школьников Санкт-Петербургского государственного университета\n" +
                        "', '11 17 25 6 48 94 36 42 60 59 68 83 74 31 92 98 102', 23, 'Олимпиада школьников Санкт-Петербургского государственного университета\n" +
                        "', 'Олимпиада школьников Санкт-Петербургского государственного университета\n" +
                        "', 'Олимпиада школьников Санкт-Петербургского государственного университета\n" +
                        "', 'Олимпиада школьников Санкт-Петербургского государственного университета\n" +
                        "', 'Олимпиада школьников Санкт-Петербургского государственного университета\n" +
                        "', 'http://www.olympiada.spbu.ru/');\n" +
                        "INSERT INTO olimps (id, name, subjects, level, dates, organisator, place, stages, privileges, site) VALUES (60, 'Олимпиада школьников федерального государственного бюджетного образовательного учреждения высшего образования «Всероссийский государственный университет юстиции (РПА Минюста России)» «В мир права»\n" +
                        "', '42 74', 123, 'Олимпиада школьников федерального государственного бюджетного образовательного учреждения высшего образования «Всероссийский государственный университет юстиции (РПА Минюста России)» «В мир права»\n" +
                        "', 'Олимпиада школьников федерального государственного бюджетного образовательного учреждения высшего образования «Всероссийский государственный университет юстиции (РПА Минюста России)» «В мир права»\n" +
                        "', 'Олимпиада школьников федерального государственного бюджетного образовательного учреждения высшего образования «Всероссийский государственный университет юстиции (РПА Минюста России)» «В мир права»\n" +
                        "', 'Олимпиада школьников федерального государственного бюджетного образовательного учреждения высшего образования «Всероссийский государственный университет юстиции (РПА Минюста России)» «В мир права»\n" +
                        "', 'Олимпиада школьников федерального государственного бюджетного образовательного учреждения высшего образования «Всероссийский государственный университет юстиции (РПА Минюста России)» «В мир права»\n" +
                        "', 'https://rpa-mu.ru/');\n" +
                        "INSERT INTO olimps (id, name, subjects, level, dates, organisator, place, stages, privileges, site) VALUES (61, 'Олимпиада Юношеской математической школы\n" +
                        "', 59, 3, 'Олимпиада Юношеской математической школы\n" +
                        "', 'Олимпиада Юношеской математической школы\n" +
                        "', 'Олимпиада Юношеской математической школы\n" +
                        "', 'Олимпиада Юношеской математической школы\n" +
                        "', 'Олимпиада Юношеской математической школы\n" +
                        "', 'https://rpa-mu.ru/');\n" +
                        "INSERT INTO olimps (id, name, subjects, level, dates, organisator, place, stages, privileges, site) VALUES (62, 'Открытая межвузовская олимпиада школьников Сибирского Федерального округа «Будущее Сибири»\n" +
                        "', '92 98', 2, 'Открытая межвузовская олимпиада школьников Сибирского Федерального округа «Будущее Сибири»\n" +
                        "', 'Открытая межвузовская олимпиада школьников Сибирского Федерального округа «Будущее Сибири»\n" +
                        "', 'Открытая межвузовская олимпиада школьников Сибирского Федерального округа «Будущее Сибири»\n" +
                        "', 'Открытая межвузовская олимпиада школьников Сибирского Федерального округа «Будущее Сибири»\n" +
                        "', 'Открытая межвузовская олимпиада школьников Сибирского Федерального округа «Будущее Сибири»\n" +
                        "', 'https://rsr-olymp.ru/olympiada-sfo.nstu.ru');\n" +
                        "INSERT INTO olimps (id, name, subjects, level, dates, organisator, place, stages, privileges, site) VALUES (63, 'Открытая олимпиада Северо-Кавказского федерального университета среди учащихся образовательных организаций «45 параллель»\n" +
                        "', 17, 23, 'Открытая олимпиада Северо-Кавказского федерального университета среди учащихся образовательных организаций «45 параллель»\n" +
                        "', 'Открытая олимпиада Северо-Кавказского федерального университета среди учащихся образовательных организаций «45 параллель»\n" +
                        "', 'Открытая олимпиада Северо-Кавказского федерального университета среди учащихся образовательных организаций «45 параллель»\n" +
                        "', 'Открытая олимпиада Северо-Кавказского федерального университета среди учащихся образовательных организаций «45 параллель»\n" +
                        "', 'Открытая олимпиада Северо-Кавказского федерального университета среди учащихся образовательных организаций «45 параллель»\n" +
                        "', 'https://rsr-olymp.ru/olymp.ncfu.ru');\n" +
                        "INSERT INTO olimps (id, name, subjects, level, dates, organisator, place, stages, privileges, site) VALUES (64, 'Открытая олимпиада школьников\n" +
                        "', '36 59', 2, 'Открытая олимпиада школьников\n" +
                        "', 'Открытая олимпиада школьников\n" +
                        "', 'Открытая олимпиада школьников\n" +
                        "', 'Открытая олимпиада школьников\n" +
                        "', 'Открытая олимпиада школьников\n" +
                        "', 'https://rsr-olymp.ru/olymp.ncfu.ru');\n" +
                        "INSERT INTO olimps (id, name, subjects, level, dates, organisator, place, stages, privileges, site) VALUES (65, 'Открытая олимпиада школьников по программированию\n" +
                        "', 36, 13, 'Открытая олимпиада школьников по программированию\n" +
                        "', 'Открытая олимпиада школьников по программированию\n" +
                        "', 'Открытая олимпиада школьников по программированию\n" +
                        "', 'Открытая олимпиада школьников по программированию\n" +
                        "', 'Открытая олимпиада школьников по программированию\n" +
                        "', 'http://www.olympiads.ru/zaoch/');\n" +
                        "INSERT INTO olimps (id, name, subjects, level, dates, organisator, place, stages, privileges, site) VALUES (66, 'Открытая олимпиада школьников по программированию «Когнитивные технологии»\n" +
                        "', 36, 1, 'Открытая олимпиада школьников по программированию «Когнитивные технологии»\n" +
                        "', 'Открытая олимпиада школьников по программированию «Когнитивные технологии»\n" +
                        "', 'Открытая олимпиада школьников по программированию «Когнитивные технологии»\n" +
                        "', 'Открытая олимпиада школьников по программированию «Когнитивные технологии»\n" +
                        "', 'Открытая олимпиада школьников по программированию «Когнитивные технологии»\n" +
                        "', 'http://olymp.misis.ru/');\n" +
                        "INSERT INTO olimps (id, name, subjects, level, dates, organisator, place, stages, privileges, site) VALUES (67, 'Открытая региональная межвузовская олимпиада вузов Томской области (ОРМО)\n" +
                        "', '17 42 58 59 81 92', 2, 'Открытая региональная межвузовская олимпиада вузов Томской области (ОРМО)\n" +
                        "', 'Открытая региональная межвузовская олимпиада вузов Томской области (ОРМО)\n" +
                        "', 'Открытая региональная межвузовская олимпиада вузов Томской области (ОРМО)\n" +
                        "', 'Открытая региональная межвузовская олимпиада вузов Томской области (ОРМО)\n" +
                        "', 'Открытая региональная межвузовская олимпиада вузов Томской области (ОРМО)\n" +
                        "', 'http://abiturient.tsu.ru/ru/content/ormo');\n" +
                        "INSERT INTO olimps (id, name, subjects, level, dates, organisator, place, stages, privileges, site) VALUES (68, 'Открытая химическая олимпиада\n" +
                        "', 98, 23, 'Открытая химическая олимпиада\n" +
                        "', 'Открытая химическая олимпиада\n" +
                        "', 'Открытая химическая олимпиада\n" +
                        "', 'Открытая химическая олимпиада\n" +
                        "', 'Открытая химическая олимпиада\n" +
                        "', 'https://rsr-olymp.ru/chem.mipt.ru');\n" +
                        "INSERT INTO olimps (id, name, subjects, level, dates, organisator, place, stages, privileges, site) VALUES (69, 'Отраслевая олимпиада школьников «Газпром»\n" +
                        "', '36 92 98', 2, 'Отраслевая олимпиада школьников «Газпром»\n" +
                        "', 'Отраслевая олимпиада школьников «Газпром»\n" +
                        "', 'Отраслевая олимпиада школьников «Газпром»\n" +
                        "', 'Отраслевая олимпиада школьников «Газпром»\n" +
                        "', 'Отраслевая олимпиада школьников «Газпром»\n" +
                        "', 'https://rsr-olymp.ru/olympiad.gazprom.ru');\n" +
                        "INSERT INTO olimps (id, name, subjects, level, dates, organisator, place, stages, privileges, site) VALUES (70, 'Отраслевая физико-математическая олимпиада школьников «Росатом»\n" +
                        "', '59 92', 3, 'Отраслевая физико-математическая олимпиада школьников «Росатом»\n" +
                        "', 'Отраслевая физико-математическая олимпиада школьников «Росатом»\n" +
                        "', 'Отраслевая физико-математическая олимпиада школьников «Росатом»\n" +
                        "', 'Отраслевая физико-математическая олимпиада школьников «Росатом»\n" +
                        "', 'Отраслевая физико-математическая олимпиада школьников «Росатом»\n" +
                        "', 'https://admission.mephi.ru/olympiads/rosatom');\n" +
                        "INSERT INTO olimps (id, name, subjects, level, dates, organisator, place, stages, privileges, site) VALUES (71, 'Плехановская олимпиада школьников\n" +
                        "', '6 67 102 96 81', 12, 'Плехановская олимпиада школьников\n" +
                        "', 'Плехановская олимпиада школьников\n" +
                        "', 'Плехановская олимпиада школьников\n" +
                        "', 'Плехановская олимпиада школьников\n" +
                        "', 'Плехановская олимпиада школьников\n" +
                        "', 'http://olymp.rea.ru/');\n" +
                        "INSERT INTO olimps (id, name, subjects, level, dates, organisator, place, stages, privileges, site) VALUES (72, 'Региональный конкурс школьников Челябинского университетского образовательного округа\n" +
                        "', '6 97 67', 23, 'Региональный конкурс школьников Челябинского университетского образовательного округа\n" +
                        "', 'Региональный конкурс школьников Челябинского университетского образовательного округа\n" +
                        "', 'Региональный конкурс школьников Челябинского университетского образовательного округа\n" +
                        "', 'Региональный конкурс школьников Челябинского университетского образовательного округа\n" +
                        "', 'Региональный конкурс школьников Челябинского университетского образовательного округа\n" +
                        "', 'https://rsr-olymp.ru/www.olymp.csu.ru');\n" +
                        "INSERT INTO olimps (id, name, subjects, level, dates, organisator, place, stages, privileges, site) VALUES (73, 'Санкт-Петербургская олимпиада школьников\n" +
                        "', '8 59 98', 3, 'Санкт-Петербургская олимпиада школьников\n" +
                        "', 'Санкт-Петербургская олимпиада школьников\n" +
                        "', 'Санкт-Петербургская олимпиада школьников\n" +
                        "', 'Санкт-Петербургская олимпиада школьников\n" +
                        "', 'Санкт-Петербургская олимпиада школьников\n" +
                        "', 'http://school.astro.spbu.ru/');\n" +
                        "INSERT INTO olimps (id, name, subjects, level, dates, organisator, place, stages, privileges, site) VALUES (74, 'Северо-Восточная олимпиада школьников\n" +
                        "', 94, 1, 'Северо-Восточная олимпиада школьников\n" +
                        "', 'Северо-Восточная олимпиада школьников\n" +
                        "', 'Северо-Восточная олимпиада школьников\n" +
                        "', 'Северо-Восточная олимпиада школьников\n" +
                        "', 'Северо-Восточная олимпиада школьников\n" +
                        "', 'http://fdop.s-vfu.ru/olimpiady-shkolnikov2/severo-vostochnaya-olimpiada-shkolnik/');\n" +
                        "INSERT INTO olimps (id, name, subjects, level, dates, organisator, place, stages, privileges, site) VALUES (75, 'Сибирская межрегиональная олимпиада школьников «Архитектурно-дизайнерское творчество»\n" +
                        "', '7 27', 3, 'Сибирская межрегиональная олимпиада школьников «Архитектурно-дизайнерское творчество»\n" +
                        "', 'Сибирская межрегиональная олимпиада школьников «Архитектурно-дизайнерское творчество»\n" +
                        "', 'Сибирская межрегиональная олимпиада школьников «Архитектурно-дизайнерское творчество»\n" +
                        "', 'Сибирская межрегиональная олимпиада школьников «Архитектурно-дизайнерское творчество»\n" +
                        "', 'Сибирская межрегиональная олимпиада школьников «Архитектурно-дизайнерское творчество»\n" +
                        "', 'http://fdop.s-vfu.ru/olimpiady-shkolnikov2/severo-vostochnaya-olimpiada-shkolnik/');\n" +
                        "INSERT INTO olimps (id, name, subjects, level, dates, organisator, place, stages, privileges, site) VALUES (76, 'Строгановская олимпиада на базе МГХПА им. С.Г. Строганова\n" +
                        "', '79 24 82 22', 2, 'Строгановская олимпиада на базе МГХПА им. С.Г. Строганова\n" +
                        "', 'Строгановская олимпиада на базе МГХПА им. С.Г. Строганова\n" +
                        "', 'Строгановская олимпиада на базе МГХПА им. С.Г. Строганова\n" +
                        "', 'Строгановская олимпиада на базе МГХПА им. С.Г. Строганова\n" +
                        "', 'Строгановская олимпиада на базе МГХПА им. С.Г. Строганова\n" +
                        "', 'http://fdop.s-vfu.ru/olimpiady-shkolnikov2/severo-vostochnaya-olimpiada-shkolnik/');\n" +
                        "INSERT INTO olimps (id, name, subjects, level, dates, organisator, place, stages, privileges, site) VALUES (77, 'Телевизионная гуманитарная олимпиада школьников «Умницы и умники»\n" +
                        "', 21, 1, 'Телевизионная гуманитарная олимпиада школьников «Умницы и умники»\n" +
                        "', 'Телевизионная гуманитарная олимпиада школьников «Умницы и умники»\n" +
                        "', 'Телевизионная гуманитарная олимпиада школьников «Умницы и умники»\n" +
                        "', 'Телевизионная гуманитарная олимпиада школьников «Умницы и умники»\n" +
                        "', 'Телевизионная гуманитарная олимпиада школьников «Умницы и умники»\n" +
                        "', 'https://abiturient.mgimo.ru/olimpiady/umniki');\n" +
                        "INSERT INTO olimps (id, name, subjects, level, dates, organisator, place, stages, privileges, site) VALUES (78, 'Турнир городов\n" +
                        "', 59, 1, 'Турнир городов\n" +
                        "', 'Турнир городов\n" +
                        "', 'Турнир городов\n" +
                        "', 'Турнир городов\n" +
                        "', 'Турнир городов\n" +
                        "', 'http://www.turgor.ru/');\n" +
                        "INSERT INTO olimps (id, name, subjects, level, dates, organisator, place, stages, privileges, site) VALUES (79, 'Турнир имени М.В. Ломоносова\n" +
                        "', '8 11 42 58 59 57 92 98', 123, 'Турнир имени М.В. Ломоносова\n" +
                        "', 'Турнир имени М.В. Ломоносова\n" +
                        "', 'Турнир имени М.В. Ломоносова\n" +
                        "', 'Турнир имени М.В. Ломоносова\n" +
                        "', 'Турнир имени М.В. Ломоносова\n" +
                        "', 'http://turlom.olimpiada.ru/');\n" +
                        "INSERT INTO olimps (id, name, subjects, level, dates, organisator, place, stages, privileges, site) VALUES (80, 'Университетская олимпиада школьников «Бельчонок»\n" +
                        "', '36 59 98', 3, 'Университетская олимпиада школьников «Бельчонок»\n" +
                        "', 'Университетская олимпиада школьников «Бельчонок»\n" +
                        "', 'Университетская олимпиада школьников «Бельчонок»\n" +
                        "', 'Университетская олимпиада школьников «Бельчонок»\n" +
                        "', 'Университетская олимпиада школьников «Бельчонок»\n" +
                        "', 'http://dovuz.sfu-kras.ru/belchonok/');";
        String q6 =
                "INSERT INTO olimps (id, name, subjects, level, dates, organisator, place, stages, privileges, site) VALUES (81, 'Учитель школы будущего\n" +
                        "', '6 97 41 67 48 104', 3, 'Учитель школы будущего\n" +
                        "', 'Учитель школы будущего\n" +
                        "', 'Учитель школы будущего\n" +
                        "', 'Учитель школы будущего\n" +
                        "', 'Учитель школы будущего\n" +
                        "', 'https://www.mgpu.ru/olimpidada_teachers/');\n" +
                        "INSERT INTO olimps (id, name, subjects, level, dates, organisator, place, stages, privileges, site) VALUES (82, 'Филологическая олимпиада для школьников 5-11 классов «Юный словесник»\n" +
                        "', 94, 2, 'Филологическая олимпиада для школьников 5-11 классов «Юный словесник»\n" +
                        "', 'Филологическая олимпиада для школьников 5-11 классов «Юный словесник»\n" +
                        "', 'Филологическая олимпиада для школьников 5-11 классов «Юный словесник»\n" +
                        "', 'Филологическая олимпиада для школьников 5-11 классов «Юный словесник»\n" +
                        "', 'Филологическая олимпиада для школьников 5-11 классов «Юный словесник»\n" +
                        "', 'https://www.mgpu.ru/olimpidada_teachers/');\n" +
                        "INSERT INTO olimps (id, name, subjects, level, dates, organisator, place, stages, privileges, site) VALUES (83, 'Межрегиональная открытая олимпиада по музыкально-теоретическим дисциплинам для учащихся детских музыкальных школ и детских школ искусств\n" +
                        "', 86, 3, 'Межрегиональная открытая олимпиада по музыкально-теоретическим дисциплинам для учащихся детских музыкальных школ и детских школ искусств\n" +
                        "', 'Межрегиональная открытая олимпиада по музыкально-теоретическим дисциплинам для учащихся детских музыкальных школ и детских школ искусств\n" +
                        "', 'Межрегиональная открытая олимпиада по музыкально-теоретическим дисциплинам для учащихся детских музыкальных школ и детских школ искусств\n" +
                        "', 'Межрегиональная открытая олимпиада по музыкально-теоретическим дисциплинам для учащихся детских музыкальных школ и детских школ искусств\n" +
                        "', 'Межрегиональная открытая олимпиада по музыкально-теоретическим дисциплинам для учащихся детских музыкальных школ и детских школ искусств\n" +
                        "', 'https://www.mgpu.ru/olimpidada_teachers/');\n" +
                        "INSERT INTO olimps (id, name, subjects, level, dates, organisator, place, stages, privileges, site) VALUES (84, 'Всероссийская олимпиада школьников', '6 8 11 17 36 40 41 42 47 48 58 59 67 1 68 74 90 92 93 97 98 101 102', 1, 'ва', 'ва', 'в', 'в', 'в', 'в');";


        String q3 = "INSERT INTO subjects (id, subject) VALUES (1, 'ОБЖ');\n" +
                "INSERT INTO subjects (id, subject) VALUES (2, 'автоматизация бизнес-процессов');\n" +
                "INSERT INTO subjects (id, subject) VALUES (3, 'автономные транспортные системы');\n" +
                "INSERT INTO subjects (id, subject) VALUES (4, 'академический рисунок');\n" +
                "INSERT INTO subjects (id, subject) VALUES (5, 'анализ космических снимков и геопространственных данных');\n" +
                "INSERT INTO subjects (id, subject) VALUES (6, 'английский язык');\n" +
                "INSERT INTO subjects (id, subject) VALUES (7, 'архитектура');\n" +
                "INSERT INTO subjects (id, subject) VALUES (8, 'астрономия');\n" +
                "INSERT INTO subjects (id, subject) VALUES (9, 'аэрокосмические системы');\n" +
                "INSERT INTO subjects (id, subject) VALUES (10, 'беспилотные авиационные системы');\n" +
                "INSERT INTO subjects (id, subject) VALUES (11, 'биология');\n" +
                "INSERT INTO subjects (id, subject) VALUES (12, 'большие данные и машинное обучение');\n" +
                "INSERT INTO subjects (id, subject) VALUES (13, 'водные робототехнические системы');\n" +
                "INSERT INTO subjects (id, subject) VALUES (14, 'востоковедение');\n" +
                "INSERT INTO subjects (id, subject) VALUES (15, 'генетика');\n" +
                "INSERT INTO subjects (id, subject) VALUES (16, 'геномное редактирование');\n" +
                "INSERT INTO subjects (id, subject) VALUES (17, 'география');\n" +
                "INSERT INTO subjects (id, subject) VALUES (18, 'геология');\n" +
                "INSERT INTO subjects (id, subject) VALUES (19, 'графика');\n" +
                "INSERT INTO subjects (id, subject) VALUES (20, 'графический дизайн');\n" +
                "INSERT INTO subjects (id, subject) VALUES (21, 'гуманитарные и социальные науки');\n" +
                "INSERT INTO subjects (id, subject) VALUES (22, 'дизайн');\n" +
                "INSERT INTO subjects (id, subject) VALUES (23, 'естественные науки');\n" +
                "INSERT INTO subjects (id, subject) VALUES (24, 'живопись');\n" +
                "INSERT INTO subjects (id, subject) VALUES (25, 'журналистика');\n" +
                "INSERT INTO subjects (id, subject) VALUES (26, 'изобразительное искусство');\n" +
                "INSERT INTO subjects (id, subject) VALUES (27, 'изобразительные и прикладные виды искусств');\n" +
                "INSERT INTO subjects (id, subject) VALUES (28, 'инженерное дело');\n" +
                "INSERT INTO subjects (id, subject) VALUES (29, 'инженерные биологические системы: агробиотехнологии');\n" +
                "INSERT INTO subjects (id, subject) VALUES (30, 'инженерные науки');\n" +
                "INSERT INTO subjects (id, subject) VALUES (31, 'инженерные системы');\n" +
                "INSERT INTO subjects (id, subject) VALUES (32, 'иностранные языки');\n" +
                "INSERT INTO subjects (id, subject) VALUES (33, 'инструменты народного оркестра');\n" +
                "INSERT INTO subjects (id, subject) VALUES (34, 'интеллектуальные робототехнические системы');\n" +
                "INSERT INTO subjects (id, subject) VALUES (35, 'интеллектуальные энергетические системы');\n" +
                "INSERT INTO subjects (id, subject) VALUES (36, 'информатика');\n" +
                "INSERT INTO subjects (id, subject) VALUES (37, 'информационная безопасность');\n" +
                "INSERT INTO subjects (id, subject) VALUES (38, 'информационные и коммуникационные технологии');\n" +
                "INSERT INTO subjects (id, subject) VALUES (39, 'искусственный интеллект');\n" +
                "INSERT INTO subjects (id, subject) VALUES (40, 'искусство');\n" +
                "INSERT INTO subjects (id, subject) VALUES (41, 'испанский язык');\n" +
                "INSERT INTO subjects (id, subject) VALUES (42, 'история');\n" +
                "INSERT INTO subjects (id, subject) VALUES (43, 'история искусств');\n" +
                "INSERT INTO subjects (id, subject) VALUES (44, 'история искусства и культуры');\n" +
                "INSERT INTO subjects (id, subject) VALUES (45, 'история мировых цивилизаций');\n" +
                "INSERT INTO subjects (id, subject) VALUES (46, 'история российской государственности');\n" +
                "INSERT INTO subjects (id, subject) VALUES (47, 'итальянский язык');\n" +
                "INSERT INTO subjects (id, subject) VALUES (48, 'китайский язык');\n" +
                "INSERT INTO subjects (id, subject) VALUES (49, 'комплекс предметов (физика, информатика, математика)');\n" +
                "INSERT INTO subjects (id, subject) VALUES (50, 'композитные технологии');\n" +
                "INSERT INTO subjects (id, subject) VALUES (51, 'композиция');\n" +
                "INSERT INTO subjects (id, subject) VALUES (52, 'компьютерная безопасность');\n" +
                "INSERT INTO subjects (id, subject) VALUES (53, 'компьютерное моделирование и графика');\n" +
                "INSERT INTO subjects (id, subject) VALUES (54, 'космонавтика');\n" +
                "INSERT INTO subjects (id, subject) VALUES (55, 'культурология');\n" +
                "INSERT INTO subjects (id, subject) VALUES (56, 'летающая робототехника');\n" +
                "INSERT INTO subjects (id, subject) VALUES (57, 'лингвистика');\n" +
                "INSERT INTO subjects (id, subject) VALUES (58, 'литература');\n" +
                "INSERT INTO subjects (id, subject) VALUES (59, 'математика');\n" +
                "INSERT INTO subjects (id, subject) VALUES (60, 'медицина');\n" +
                "INSERT INTO subjects (id, subject) VALUES (61, 'международные отношения и глобалистика');\n" +
                "INSERT INTO subjects (id, subject) VALUES (62, 'механика и математическое моделирование');\n" +
                "INSERT INTO subjects (id, subject) VALUES (63, 'музыкальная педагогика и исполнительство');\n" +
                "INSERT INTO subjects (id, subject) VALUES (64, 'наносистемы и наноинженерия');\n" +
                "INSERT INTO subjects (id, subject) VALUES (65, 'нанотехнологии');\n" +
                "INSERT INTO subjects (id, subject) VALUES (66, 'нейротехнологии и когнитивные науки');\n" +
                "INSERT INTO subjects (id, subject) VALUES (67, 'немецкий язык');\n" +
                "INSERT INTO subjects (id, subject) VALUES (68, 'обществознание');\n" +
                "INSERT INTO subjects (id, subject) VALUES (69, 'основы бизнеса');\n" +
                "INSERT INTO subjects (id, subject) VALUES (70, 'основы православной культуры');\n" +
                "INSERT INTO subjects (id, subject) VALUES (71, 'педагогические науки и образование');\n" +
                "INSERT INTO subjects (id, subject) VALUES (72, 'передовые производственные технологии');\n" +
                "INSERT INTO subjects (id, subject) VALUES (73, 'политология');\n" +
                "INSERT INTO subjects (id, subject) VALUES (74, 'право');\n" +
                "INSERT INTO subjects (id, subject) VALUES (75, 'предпрофессиональная');\n" +
                "INSERT INTO subjects (id, subject) VALUES (76, 'программирование');\n" +
                "INSERT INTO subjects (id, subject) VALUES (77, 'программная инженерия финансовых технологий');\n" +
                "INSERT INTO subjects (id, subject) VALUES (78, 'психология');\n" +
                "INSERT INTO subjects (id, subject) VALUES (79, 'рисунок');\n" +
                "INSERT INTO subjects (id, subject) VALUES (80, 'робототехника');\n" +
                "INSERT INTO subjects (id, subject) VALUES (81, 'русский язык');\n" +
                "INSERT INTO subjects (id, subject) VALUES (82, 'скульптура');\n" +
                "INSERT INTO subjects (id, subject) VALUES (83, 'социология');\n" +
                "INSERT INTO subjects (id, subject) VALUES (84, 'спутниковые системы');\n" +
                "INSERT INTO subjects (id, subject) VALUES (85, 'струнные инструменты');\n" +
                "INSERT INTO subjects (id, subject) VALUES (86, 'теория и история музыки');\n" +
                "INSERT INTO subjects (id, subject) VALUES (87, 'техника и технологии');\n" +
                "INSERT INTO subjects (id, subject) VALUES (88, 'технический рисунок и декоративная композиция');\n" +
                "INSERT INTO subjects (id, subject) VALUES (89, 'технологии беспроводной связи');\n" +
                "INSERT INTO subjects (id, subject) VALUES (90, 'технология');\n" +
                "INSERT INTO subjects (id, subject) VALUES (91, 'умный город');\n" +
                "INSERT INTO subjects (id, subject) VALUES (92, 'физика');\n" +
                "INSERT INTO subjects (id, subject) VALUES (93, 'физическая культура');\n" +
                "INSERT INTO subjects (id, subject) VALUES (94, 'филология');\n" +
                "INSERT INTO subjects (id, subject) VALUES (95, 'философия');\n" +
                "INSERT INTO subjects (id, subject) VALUES (96, 'финансовая грамотность');\n" +
                "INSERT INTO subjects (id, subject) VALUES (97, 'французский язык');\n" +
                "INSERT INTO subjects (id, subject) VALUES (98, 'химия');\n" +
                "INSERT INTO subjects (id, subject) VALUES (99, 'хоровое дирижирование');\n" +
                "INSERT INTO subjects (id, subject) VALUES (100, 'черчение');\n" +
                "INSERT INTO subjects (id, subject) VALUES (101, 'экология');\n" +
                "INSERT INTO subjects (id, subject) VALUES (102, 'экономика');\n" +
                "INSERT INTO subjects (id, subject) VALUES (103, 'электроника и вычислительная техника');\n" +
                "INSERT INTO subjects (id, subject) VALUES (104, 'японский язык');";


        String[] arr = q.split("\n");
        String[] arr2 = q2.split("INSERT");
        String[] arr3 = q3.split("\n");
        String[] arr4 = q4.split("INSERT");
        String[] arr5 = q5.split("INSERT");
        String[] arr6 = q6.split("INSERT");
        for (int i = 0; i < arr.length; i++) {
            db.execSQL(arr[i]);
        }

        for (int i = 0; i < arr2.length; i++) {

            System.out.println("INSERT " + arr2[i]);
            if (!arr2[i].equals("")) {
                arr2[i] = arr2[i].replace("\n", "");
                db.execSQL("INSERT " + arr2[i]);
            }
        }
        for (int i = 0; i < arr4.length; i++) {

            System.out.println("INSERT " + arr4[i]);
            if (!arr4[i].equals("")) {
                arr4[i] = arr4[i].replace("\n", "");
                db.execSQL("INSERT " + arr4[i]);
            }
        }
        for (int i = 0; i < arr5.length; i++) {

            System.out.println("INSERT " + arr5[i]);
            if (!arr5[i].equals("")) {
                arr5[i] = arr5[i].replace("\n", "");
                db.execSQL("INSERT " + arr5[i]);
            }
        }
        for (int i = 0; i < arr6.length; i++) {

            System.out.println("INSERT " + arr2[i]);
            if (!arr6[i].equals("")) {
                arr6[i] = arr6[i].replace("\n", "");
                db.execSQL("INSERT " + arr6[i]);
            }
        }
        for (int i = 0; i < arr3.length; i++) {


            db.execSQL(arr3[i]);
        }

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }


}




