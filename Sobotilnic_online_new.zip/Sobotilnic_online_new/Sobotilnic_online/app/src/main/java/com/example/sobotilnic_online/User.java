package com.example.sobotilnic_online;

public class User {
    public String id, name, password, sec_key, status="", city="";

    public User(String id, String name, String password, String sec_key, String status, String city) {
        this.id = id;
        this.name = name;
        this.password = password;
        this.sec_key = sec_key;
        this.status = status;
        this.city = city;
    }

    public User() {
    }

    public User(String id, String name, String password, String sec_key) {
        this.id = id;
        this.name = name;
        this.password = password;
        this.sec_key = sec_key;
    }

}
