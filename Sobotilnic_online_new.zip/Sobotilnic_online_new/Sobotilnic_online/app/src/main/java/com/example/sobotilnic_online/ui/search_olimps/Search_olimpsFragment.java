package com.example.sobotilnic_online.ui.search_olimps;

import android.app.Dialog;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.sobotilnic_online.Login_or_sign_in;
import com.example.sobotilnic_online.MyOpenHelper;
import com.example.sobotilnic_online.R;
import com.example.sobotilnic_online.Subjects_filter;
import com.example.sobotilnic_online.adapter_for_bot_subjects;
import com.example.sobotilnic_online.ui.my_olimps.Class_for_list;
import com.example.sobotilnic_online.ui.my_olimps.adapter_for_my_olimps_list;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Arrays;

public class Search_olimpsFragment extends Fragment {
    ArrayList<Class_for_list> search_olimps = new ArrayList<>();
    RecyclerView search_olimps_results_list;
    Button search_olimps_filter_button;
    ImageButton search_button;
    EditText editText_for_olimps_search;
    TextView textView_results_count;
    Dialog dialog_for_search_olimps;
    private RecyclerView.LayoutManager layoutManager;
    static MyOpenHelper dbHelper;
    SQLiteDatabase readdb;
    SQLiteDatabase writedb;


    private Search_olimpsViewModel search_olimpsViewModel;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        search_olimpsViewModel =
                ViewModelProviders.of(this).get(Search_olimpsViewModel.class);
        View root = inflater.inflate(R.layout.fragment_search_olimps, container, false);
        final TextView textView = root.findViewById(R.id.text_search_olimps);
        search_olimpsViewModel.getText().observe(this, new Observer<String>() {
            @Override
            public void onChanged(@Nullable String s) {
                textView.setText(s);
            }
        });


        search_olimps_results_list = root.findViewById(R.id.search_olimps_result_list);
        search_olimps_filter_button = root.findViewById(R.id.search_olimps_filter_button);
        search_button = root.findViewById(R.id.search_button);

        textView_results_count = root.findViewById(R.id.textView_results_count);
        editText_for_olimps_search = root.findViewById(R.id.editText_for_olimps_search);


        dbHelper = new MyOpenHelper(getActivity().getApplicationContext(), "DB", null, 1);
        readdb = dbHelper.getReadableDatabase();
        writedb = dbHelper.getWritableDatabase();

        ArrayList<String> filter = adapter_for_bot_subjects.choice_sub;


        Cursor cursor = readdb.rawQuery("select id, name, subjects, level, dates, organisator, place, stages, privileges, site from olimps", null);
        cursor.moveToFirst();
        int n = cursor.getCount();
        for (int i = 0; i < n; i++) {
            cursor.moveToPosition(i);
            search_olimps.add(new Class_for_list(cursor.getInt(0), cursor.getString(1)));

        }


        adapter_for_search_olimps adapter_for_olimps = new adapter_for_search_olimps(search_olimps);

        layoutManager = new LinearLayoutManager(getActivity().getApplicationContext());
        search_olimps_results_list.setLayoutManager(layoutManager);
        search_olimps_results_list.setAdapter(adapter_for_olimps);
        System.out.println("oooo");

        //dialog_for_search_olimps = new Dialog(getActivity());
        //System.out.println("ppppp");
        //dialog_for_search_olimps.setContentView(R.layout.dialog_for_subject_filter);

        //TextView text = (TextView) root.findViewById(R.id.text_for_search_olimps_dialog);
        //text.setText("Для восстановления пароля напишите на почту dina_gdr@mail.ru, указав в письме тему *Пароль* и направив мне ваш логин и секретное слово. В течение дня придет ответ!");


        search_olimps_filter_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                //alert.show();
                Intent i = new Intent(v.getContext(), Subjects_filter.class);
                v.getContext().startActivity(i);

            }
        });


        search_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //alert.show();
                search_olimps.clear();
                String[] olimp_sub_2 = new String[filter.size()];


                if (Subjects_filter.flag == true) {
                    for (int j = 0; j < filter.size(); j++) {
                        System.out.println("ppppppp" + filter.get(j));
                        Cursor new_cursor = readdb.rawQuery("select id, subject from Subjects WHERE subject='" + filter.get(j) + "'", null);
                        new_cursor.moveToPosition(0);
                        System.out.println("oooo" + new_cursor);
                        olimp_sub_2[j] = new_cursor.getString(0);

                    }
                }
                if (filter.size() == 0) {
                    Subjects_filter.flag = false;
                }


                for (int i = 0; i < n; i++) {
                    cursor.moveToPosition(i);
                    String name = cursor.getString(1);

                    System.out.println(editText_for_olimps_search.getText().toString() + " " + name);
                    String search_query = editText_for_olimps_search.getText().toString();
                    if (name.toLowerCase().contains(search_query.toLowerCase())) {
                        if (Subjects_filter.flag == true && filter.size() > 0) {
                            boolean g = false;
                            for (int j = 0; j < olimp_sub_2.length; j++) {
                                System.out.println(cursor.getString(2));
                                if (Arrays.asList(cursor.getString(2).split(" ")).contains(olimp_sub_2[j])
                                ) {
                                    g = true;
                                    break;
                                }
                            }
                            if (g == true) {
                                search_olimps.add(new Class_for_list(cursor.getInt(0), cursor.getString(1)));

                            }
                        } else {
                            search_olimps.add(new Class_for_list(cursor.getInt(0), cursor.getString(1)));
                        }

                    }


                }


                if (Subjects_filter.flag == true) {
                    Subjects_filter.flag = false;
                }


                adapter_for_olimps.notifyDataSetChanged();
                textView_results_count.setText("Найдено: " + search_olimps.size());
            }
        });

        return root;
    }
}